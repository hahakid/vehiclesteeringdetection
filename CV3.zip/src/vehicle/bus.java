package vehicle;

public class bus {

}
