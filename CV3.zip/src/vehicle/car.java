package vehicle;

import java.util.ArrayList;

import android.util.Log;

import com.turn.waveinfo;
import com.util.statistic;

public class car {
	final int leftturn=1;
	final int rightturn=2;
	final int leftlane=3;
	final int rightlane=4;
	final int leftuturn=5;
	final int rightuturn=6;
	
	//综合评分list,分别存放转向、变道、掉头和其他的分数。
	ArrayList<Float> turnscore=new ArrayList<Float>();//转向
	ArrayList<Float> lanescore=new ArrayList<Float>();//变道
	ArrayList<Float> uturnscore=new ArrayList<Float>();//掉头
	ArrayList<Float> curvescore=new ArrayList<Float>();//曲线行驶
	ArrayList<Float> other=new ArrayList<Float>();//其他
	statistic s=new statistic();//更新统计量
	
	public float state(int s,float speed,ArrayList<waveinfo> mw){
		Log.e("car-state",mw.size()+" ");
		
		switch(s){
		//case 0: return other();//
		case 3: return turn(speed,true,mw);
		case 4: return lane(speed,true,mw);
		case 5: return uturn(speed,true,mw);
		case 6: return curve(speed,true,mw);
		default: return 0;//其它
		}
		
		
	}
	
	//暂时没有多curve的评判，因为curve的速度限制与具体的转向半径有关，如果半径足够大，速度可以提升。但是转向总角度如果大于某个值说明车辆一直在兜圈子，
	//可以展示设置为一个简单的二值逻辑，>a 就无效，其余有效，其中a>360
	private float curve(float speed, boolean lr,ArrayList<waveinfo> mwave) {
		// TODO Auto-generated method stub
		float degree=540;
		float newdegree=0;
		float newavg=0;
		long newdur=0;
		int size=mwave.size();
		float score=0;
		for(int i=0;i<size;i++){
			waveinfo w=mwave.get(i);
			newavg+=Math.abs(w.getavg());//在这里取正
		//	newmax+=Math.abs(w.getmax());
			newdur+=w.getdur();
		}
		newdegree=(float) (newavg*newdur*180/Math.PI/1000);
//		因为没有分析其他参数，没有使用count2score
		
		if(newdegree>degree)score=2;
		else score=5;
		curvescore.add(score);//添加 总分数
		if(score<3)s.aggcurve();//统计中的危险弯道更新
		return score;
	}
	
	//用于处理>=4个波及其他的情况
	public void other(int size){
		if(size>=4)other.add((float) 0);
	};
	
	//直接对比总值和最值
	private float uturn(float speed, boolean lr,ArrayList<waveinfo> mwave) {
		// TODO Auto-generated method stub
		int count=0;
		int wdur=10000;//ms
		float wmax=(float) 0.5;
		float wavg=(float) 0.31;		
		
		
		float newavg=0;
		float newmax=0;
		long newdur=0;
		int size=mwave.size();
		for(int i=0;i<size;i++){
			waveinfo w=mwave.get(i);
			newavg+=Math.abs(w.getavg());//在这里取正
			newmax+=Math.abs(w.getmax());
			newdur+=w.getdur();
		}
		//除了时间不变，均值和最值都需要求 均值
				newavg=newavg/size;
				newmax=newmax/size;
		
		if(newavg<=wavg*1.25&&newavg>=wavg*0.75)count++;
		if(newmax<=wmax*1.25&&newmax>=wmax*0.75)count++;
		if(newdur>=wdur*0.75)count++;//newdur<=wdur*1.25&&
		float score=count2score(count);
		uturnscore.add(score);//加入掉头的统计列表
		if(score<3)s.agguturn();//统计中的危险掉头更新
		return score;	
				
	}

	//传递到变道的分2种情况，1.两个波的 2.非两个波的
	private float lane(float speed, boolean lr,ArrayList<waveinfo> mwave) {
		// TODO Auto-generated method stub
		int size=mwave.size();
	
		
		int wdur1=1500;//ms
		float wmax1=(float) 0.1;
		float wavg1=(float) 0.08;		
		int wdur2=1500;//ms
		float wmax2=(float) 0.1;
		float wavg2=(float) 0.08;		
		
		
		
		
		if(size==2){//两个波，分别求然后返回均值
			int count1=0,count2=0;
			waveinfo w1=mwave.get(0);
			waveinfo w2=mwave.get(1);
			float avg1=Math.abs(w1.getavg());//只有时间是必为正的
			float max1=Math.abs(w1.getmax());
			float avg2=Math.abs(w2.getavg());
			float max2=Math.abs(w2.getmax());
			
			//获取第一个波的count值
			if(avg1<=wavg1*1.25&&avg1>=wavg1*0.75)count1++;
			if(max1<=wmax1*1.25&&max1>=wmax1*0.75)count1++;
			if(w1.getdur()>=wdur1*0.75)count1++;//w1.getdur()<=wdur1*1.25&&	
			//获取第二个波的count值
			if(avg2<=wavg2*1.25&&avg2>=wavg2*0.75)count1++;
			if(max2<=wmax2*1.25&&max2>=wmax2*0.75)count1++;
			if(w2.getdur()>=wdur2*0.75)count1++;	//w2.getdur()<=wdur2*1.25&&
			float score=(count2score(count1)+count2score(count2))/2;
			lanescore.add(score);//加入变道统计列表
			if(score<3)s.agglane();//统计中的危险变道更新
			return score;
			}
		else{//一个/三个波情况，综合比较
			int count=0;
			float newavg=0;
			float newmax=0;
			long  newdur=0;
			for(int i=0;i<size;i++){
				waveinfo w=mwave.get(i);
				newavg+=Math.abs(w.getavg());//在这里取正
				newmax+=Math.abs(w.getmax());
				newdur+=w.getdur();
			}
			//除了时间不变，均值和最值都需要求 均值
					newavg=newavg/size;
					newmax=newmax/size;
			
			if(newavg<=wavg1*1.25&&newavg>=wavg1*0.75)count++;
			if(newmax<=wmax1*1.25&&newmax>=wmax1*0.75)count++;
			if(newdur>=wdur1*0.75)count++;//newdur<=wdur1*1.25&&
			float score=count2score(count);
			lanescore.add(score);//加入变道统计列表
			if(score<3)s.agglane();//统计中的危险变道更新
			return score;	
		}
	}


	//其他状态，也就是没有分的
	public int other(){
		return 0;		
	}
	
	//速度，左右，先简单点不分左右，只留接口
	public float turn(float speed, boolean lr,ArrayList<waveinfo> mwave){
		if(speed<15)speed=10;
		if(speed<25)speed=20;
		if(speed<35)speed=30;
		//都不是，速度保持原，会在switch进入default
		//先把mwave计算完毕，直接输入参数
		float newavg=0;
		float newmax=0;
		long newdur=0;
		int size=mwave.size();
		for(int i=0;i<size;i++){
			waveinfo w=mwave.get(i);
			newavg+=Math.abs(w.getavg());//在这里取正
			newmax+=Math.abs(w.getmax());
			newdur+=w.getdur();//时间恒正
		}
		//除了时间不变，均值和最值都需要求 均值
		newavg=newavg/size;
		newmax=newmax/size;
		
		switch((int)speed){
		case 10:return turn1(newavg,newmax,newdur);//10码的速度区间
		case 20:return turn2(newavg,newmax,newdur);//20码的速度区间
		case 30:return turn3(newavg,newmax,newdur);//30码的速度区间
		default: return 0;//大于30码 暂不设置
		}
		
	}


	private float turn3(float avg,float max,long dur) {
		// TODO Auto-generated method stub
				
				int count=0;
				int wdur=4000;
				float wmax=(float) 0.57;
				float wavg=(float) 0.36;		
				if(avg<=wavg*1.25&&avg>=wavg*0.75)count++;
				if(max<=wmax*1.25&&max>=wmax*0.75)count++;
				if(dur>=wdur*0.75)count++;//dur<=wdur*1.25&&
				float score=count2score(count);
				turnscore.add(score);//加入到转向分数
				if(score<3)s.aggturn();//统计中的危险转向更新
				
				return score;
	}


	private float turn2(float avg,float max,long dur) {
		// TODO Auto-generated method stub
		
		int count=0;
		int wdur=5000;
		float wmax=(float) 0.37;
		float wavg=(float) 0.26;		
		if(avg<=wavg*1.25&&avg>=wavg*0.75)count++;
		if(max<=wmax*1.25&&max>=wmax*0.75)count++;
		if(dur>=wdur*0.75)count++;	//dur<=wdur*1.25&&
		float score=count2score(count);
		turnscore.add(score);//加入到转向分数
		if(score<3)s.aggturn();//统计中的危险转向更新
		return score;
	}

	//前后浮动25%
	private float turn1(float avg,float max,long dur) {
		// TODO Auto-generated method stub
		int count=0;
		int wdur=6000;
		float wmax=(float) 0.3;
		float wavg=(float) 0.2;		
		if(avg<=wavg*1.25&&avg>=wavg*0.75)count++;
		if(max<=wmax*1.25&&max>=wmax*0.75)count++;
		if(dur>=wdur*0.75)count++;	//去除了时间的上界 dur<=wdur*1.25&&
		float score=count2score(count);
		turnscore.add(score);//加入到转向分数
		if(score<3)s.aggturn();//统计中的危险转向更新
		return score;
	}
	//按分级制返回评分3个都符合5 2个符合4 一个符合2没有符合1
	private int count2score(int count){
		switch(count){
		case 0:return 1;
		case 1:return 2;
		case 2:return 4;
		case 3:return 5;
		default:return 0;
		}
	}
	
	
	
	
	
	//////////对统计列表的分析,在最后启动计算
	private double totalscore=0.0;//总均分
	private double totalpass=0.0;//总通过率
	private int totalcount=0;//总数
	private double turnpass=0.0;//转向合格率
	private double lanepass=0.0;//变道合格率
	private double uturnpass=0.0;//掉头合格率
	private double curvepass=0.0;//曲线合格率
	
	
	public String calscore(){
		
		for(float a:turnscore){
			totalcount++;
			totalscore+=a;
			if(a>3)turnpass++;
		}
		
		for(float a:lanescore){
			totalcount++;
			totalscore+=a;
			if(a>3)lanepass++;
		}
		
		for(float a:uturnscore){
			totalcount++;
			totalscore+=a;
			if(a>3)uturnpass++;
		}
		
		for(float a:curvescore){
			totalcount++;
			totalscore+=a;
			if(a>3)curvepass++;
		}
		
		
		for(float a:other){//同时记录
			totalcount++;
			totalscore+=a;
		}
		
		if(totalcount!=0)totalpass=(turnpass+lanepass+uturnpass+curvepass)/totalcount;
		String warning="";
		
		//转向
		{if(turnscore.size()==0)turnpass=0;
		else turnpass=turnpass/turnscore.size();
		}
		//变道
		{if(lanescore.size()==0)lanepass=0;
		else lanepass=lanepass/lanescore.size();
		}
		//掉头
		{if(uturnscore.size()==0)uturnpass=0;
		else uturnpass=uturnpass/uturnscore.size();
		}
		//曲线
		{if(curvescore.size()==0)curvepass=0;
		else curvepass=curvepass/curvescore.size();
		}
		
		
		if(totalscore!=0)totalscore=totalscore/totalcount*20;
		
		
		
		String result=" 总评分： "+totalscore+
				"\n 总合格率："+totalpass+
				"\n 转向合格率： "+turnpass+
				"\n 变道合格率： "+lanepass+
				"\n 掉头合格率： "+uturnpass+"\n";
		
		if(turnpass<=0.6&&turnpass!=0)warning+="warn of turn!\n"+turnpass;
		if(lanepass<=0.6&&lanepass!=0)warning+="warn of lane!\n"+lanepass;
		if(uturnpass<=0.6&&uturnpass!=0)warning+="warn of uturn!\n"+uturnpass;
		
		Log.e("car-result",result);
		Log.e("car-warning",warning+" ");
		
		return result+warning;
	}
	
	//大于3分的转向/总转向
	public double getturnp(){
		return turnpass;
	}
	//大于3分的变道/总变道
	public double getlanep(){
		return lanepass;
	}
	////大于3分的掉头/总掉头
	public double getuturnp(){
		return uturnpass;
	}
	//通过率，>3分事件/总事件
	public double gettp(){
		return totalpass;
	}
	//总分数=均值
	public double gettscore(){
		return totalscore;
	}
	
}
