package vehicle;

public class truck {

}
