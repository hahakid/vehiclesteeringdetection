package com.drivingpattern;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.DTW.DTWDistance;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.LocationClientOption.LocationMode;
import com.distance.accdistance;
import com.distance.distance;
import com.distance.gpsdistance;
import com.log.sensorlog;
import com.route.mapfunction;
import com.route.routepoints;
import com.speed.GPSspeed;
import com.turn.multiwave;
import com.turn.tbump;
import com.util.Triple;

import com.util.correct;
import com.util.statistic;

/**
 * 
 * @author Windows
 * 
 */
public class core extends Activity implements SensorEventListener {
	// 时间制式
	// SimpleDateFormat fd = new SimpleDateFormat("yyyyMMdd "); // 年-月-日:文件名
	SimpleDateFormat ft = new SimpleDateFormat("HH:mm:ss:"); // 时-分-秒
	// SimpleDateFormat fa = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss：   "); //
	// 时-分-秒
	// 把手机先按正反上下左右 分为abcdef面
	private static String up;
	private static String down;
	private static String front;
	private static String back;
	private static String left;
	private static String right;
	java.text.DecimalFormat df = new java.text.DecimalFormat("###.##");
	private boolean flag = false;// 检测

	public String bumpresult = null;
	private DTWDistance DTW;// 计算DTW距离
	// private LinkedList<float[]> l_info, c_info; // 上一个last

	// private float gpsspeed = 0;
	private long gpstimer;
	GPSspeed mgs = new GPSspeed();

	float[] max;// 几个传感器的最大值,用于分级,分别是40、20、40
	// abump mybump = new abump();// 检测角速度的波形
	tbump mybump = new tbump();// 检测角速度的波形
	multiwave mywaves = new multiwave();

	private TextView cstate;// 状态显示盘
	private TextView LocationResult;// 定位信息盘
	private TextView logMsg;
	private TextView gps_speed;// gps速度，加速度显示

	// 传感器类型变量
	private Sensor mAccelerometer;// 加速度
	private Sensor mGravity;// 重力
	private Sensor mGyroscope;// 加速度
	private Sensor mCompass;// 罗盘磁力计

	// 存放传感器参数
	float[] accelerometerValues = new float[3]; // 存放加速度三维
	float[] magneticFieldValues = new float[3];// 磁场，罗盘
	float[] gravityValues = new float[3]; // 存放重力三维
	float[] gyroscopeValues = new float[3];// 存放陀螺仪转角

	private float ax = 0, ay = 0, az = 0;// 存放加速度x,y
	// private float gx = 0, gy = 0, gz = 0;// 存放重力三维
	private float dx = 0, dy = 0, dz = 0;// 存放陀螺仪转角
	private float cx = 0;// 磁场，罗盘

	private String as, gs, ds, cs;

	private SensorManager mSensorManager;

	// private float[] dis=new float[4];

	// 时间控制的,单位毫秒ms 1000ms=1s
	private long lastUpdateTime, begintime;// 系统初始化时间
	private static final int UPTATE_ORIENTATION_TIME = 100;// 0.1s左右检测一次方向变化,1s太长
	// 缩小采样间隔
	private static final int UPTATE_INTERVAL_TIME = 20;

	// private static final int UPTATE_INTERVAL_TIME_1 = 500;

	private accdistance md1 = new accdistance();// 传感器积分位移
	private gpsdistance md2 = new gpsdistance();// gps距离

	private String mTest1 = "acceleration";// 加速按钮
	private String mTest2 = "deceleration";// 减速按钮
	private String mTest3 = "turnleft";// 左转按钮
	private String mTest4 = "turnright";// 右转按钮
	private String mTest5 = "U-turn";// 掉头按钮
	private String mTest6 = "L-lane";// 左变道按钮
	private String mTest7 = "R-lane";// 右变道按钮

	private Button mButton;
	private Button startLocation;// 开启/停止定位按键
	private Button route;

	private int timecount;// 时间片
	private String formattime;
	// 定位变量
	public LocationClient mLocationClient;// 定位服务的客户端
	public MyLocationListener mMyLocationListener;
	public Vibrator mVibrator;

	//记录修正值，其实加速度可能不需要修正，静止状态下是没有数值反应的
	private float axfix = 0, ayfix = 0, azfix = 0;
//	private float dxfix = 0, dyfix = 0, dzfix = 0;
	private int warmup = 10000;// 1min 的预热采集时间(eNav 使用了5min的预热)
	// 存放预热阶段的相关数据
	private ArrayList<Float> wulax = new ArrayList<Float>();
	private ArrayList<Float> wulay = new ArrayList<Float>();
	private ArrayList<Float> wulaz = new ArrayList<Float>();
//	private ArrayList<Float> wuldx = new ArrayList<Float>();
//	private ArrayList<Float> wuldy = new ArrayList<Float>();
//	private ArrayList<Float> wuldz = new ArrayList<Float>();

	// 预热完毕之后清空
	private void initwp() {
		wulax.clear();
		wulay.clear();
		wulaz.clear();
//		wuldx.clear();
//		wuldy.clear();
//		wuldz.clear();
	}


	correct correcter = new correct();

	boolean cflag = false;

	// 输出日志文件
	sensorlog senlog = new sensorlog();// 传感器数值日志
	sensorlog orientlog = new sensorlog();// 方向日志

	sensorlog handstatelog = new sensorlog();// 手动按钮日志
	sensorlog gpsllog = new sensorlog();// gps-location gps的定位经纬度日志
	sensorlog gpsslog = new sensorlog();// gps-speed gps的速度日志
	sensorlog autobumplog = new sensorlog();// 转向检波结果 自动检测波形日志
	sensorlog statisticlog = new sensorlog();// 总体统计结果日志
	sensorlog wavelog = new sensorlog();// 转向检波结果
	sensorlog drivinglog = new sensorlog();// 驾驶行为数据评分
	sensorlog hardwarelog = new sensorlog();// 电池、cpu信息

	sensorlog wavesdata1 = new sensorlog();// 用作wake分析的日志，完整的传感器数据信息
	sensorlog wavesdata2 = new sensorlog();// 用作wake分析的日志，速度信息，由于室内没有gps，所以只好分开存放了
	sensorlog wavesdata3 = new sensorlog();// 传感器统计值
	sensorlog wavesdata4 = new sensorlog();// 速度统计值
	
	sensorlog all = new sensorlog();// 所有传感器+所有轴+速度

	int hardwareupdatef = 60000;// 每分钟更新硬件，
	long lasthw = 0;

	private float lspeed = 0;
	private float speed = 0;

	private boolean gpsav = false;// GPS当前是否可用，是gps开启后，依据其返回值进行更新，61可用，其余不可用
	statistic mstatis = new statistic();
	distance mydistance = new distance();
	routepoints rp = new routepoints();// 绘制轨迹所需节点

	// 新转向, 存储 @时间 @方向 @角速度-dz
	List<Triple<Integer, Float, Float>> op = new ArrayList<Triple<Integer, Float, Float>>();

	/*
	 * private void initMax() { max = new float[3]; max[0] = 40;//
	 * 加速度极值变化[-20,20] max[1] = 20;// 重力加速度极值变化[-9.8,9.8] max[2] = 40;//
	 * 转角极值变化[-20,20] }
	 */
	public String getinfo(LinkedList<float[]> a) {
		String s = "";
		for (float[] b : a) {
			s = s + "|" + b[0] + "|" + b[1] + "|" + b[2] + "|" + b[3];
		}
		return s;
	}

	// 获取list的均值, 为队列的第t维
	public float getaverage(LinkedList<float[]> q, int t) {
		float average = 0, sum = 0;
		int count = 0;
		for (float[] a : q) {
			sum = sum + a[t];
			count++;
		}
		average = sum / count;
		return average;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {// 相当于初始化函数，其余类初始化在这

		super.onCreate(savedInstanceState);

		formattime = ft.format(new Date());

		DTW = new DTWDistance();
		// 加入之后，防止系统休眠
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_main);

		mLocationClient = new LocationClient(this.getApplicationContext());
		mMyLocationListener = new MyLocationListener();
		mLocationClient.registerLocationListener(mMyLocationListener);

		mVibrator = (Vibrator) getApplicationContext().getSystemService(
				Service.VIBRATOR_SERVICE);

		// mLocationClient =
		// ((LocationApplication)getApplication()).mLocationClient;
		LocationResult = (TextView) findViewById(R.id.gps_info);
		gps_speed = (TextView) findViewById(R.id.gps_speed);
		// ((LocationApplication)getApplication()).mLocationResult =
		// LocationResult;
		initGPS();
		initSensors();// 初始化控件
		logbyhand();// 手动添加转向日志
		initlog();
		inittimers();
		initroute();
		initwp();
		// Log.e("core","oncreat-init");
		monitorBatteryState();// 注册
	}

	// 初始化各计时器
	public void inittimers() {
		gpstimer = begintime = lastUpdateTime = System.currentTimeMillis();
		timecount = 0;
	}

	private void initroute() {
		route = (Button) findViewById(R.id.route);
		route.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent();
				// intent.setClass(core.this, basemap.class);
				// intent.setClass(core.this, GeometryDemo.class);
				intent.setClass(core.this, mapfunction.class);

				startActivity(intent);

			}
		});

	}

	// 初始化GPS
	private void initGPS() {
		startLocation = (Button) findViewById(R.id.GPS);
		startLocation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				InitLocation();
				if (startLocation.getText().equals(
						getString(R.string.startlocation))) {
					mLocationClient.start();
					startLocation.setText(getString(R.string.stoplocation));
				} else {
					mLocationClient.stop();
					startLocation.setText(getString(R.string.startlocation));
					logMsg("loaction stop");
				}
			}
		});
	}

	// 日志初始化
	private void initlog() {
		senlog.initfile("atest", "sensor");
		orientlog.initfile("atest", "orientation");

		handstatelog.initfile("atest", "handstate");
		gpsllog.initfile("atest", "gpsl");
		gpsslog.initfile("atest", "gpss");
		autobumplog.initfile("atest", "bumpcheck");
		statisticlog.initfile("atest", "statistic");
		wavelog.initfile("atest", "wave");
		drivinglog.initfile("atest", "dirvingscore");
		hardwarelog.initfile("atest", "hardware");
		all.initfile("atest", "all");
		wavesdata1.initfile("atest", "wavesdata1");//raw sensor data
		wavesdata2.initfile("atest", "wavesdata2");//raw speed
		wavesdata3.initfile("atest", "wavesdata3");// statistic sensor data
		wavesdata3.update("min max sd var entropy RMS quartiles_up quartiles_down");//第一个放个提示信息
		wavesdata4.initfile("atest", "wavesdata4");//statistic speed
	}

	// 百度定位初始化
	private void InitLocation() {
		LocationClientOption option = new LocationClientOption();
		option.setLocationMode(LocationMode.Hight_Accuracy);// 设置定位模式
		option.setCoorType("bd09ll");// 返回的定位结果是百度经纬度,默认值gcj02，共三种
										// bd09、bd09ll、gcj02 还有WGS84
		// 百度虽然在SDK中没有描述支持WGS84的经纬度坐标系，但是测试了一下居然可以调度到，而且这几种坐标系数值确实不一样，只有bd09略怪
		// option.setCoorType("bd09ll");// 返回的定位结果是百度经纬度,默认值gcj02，共三种
		// bd09、bd09ll、gcj02
		option.setScanSpan(1000);// 设置发起定位请求的间隔时间为5000ms
		option.setIsNeedAddress(true);// 返回的定位结果包含地址信息
		option.setNeedDeviceDirect(true);// 返回的定位结果包含手机机头的方向
		mLocationClient.setLocOption(option);
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		mLocationClient.stop();
		super.onStop();
	}

	private void filterall(int i) {

		ax = filter1(accelerometerValues[0], i);
		ay = filter1(accelerometerValues[1], i);
		az = filter1(accelerometerValues[2], i);

		dx = filter1(gyroscopeValues[0], i);
		dy = filter1(gyroscopeValues[1], i);
		dz = filter1(gyroscopeValues[2], i);

		// float[] v=calculateOrientation();
		cx = filter1(calculateOrientation(), i);
		// cy =v[1];//(calculateOrientation(),2);
		// cz =v[2];//(calculateOrientation(),3);
	}

	// private static final float NS2S = 1.0f / 1000000.0f;//ns->ms 10^6

	final SensorEventListener myListener = new SensorEventListener() {
		public void onSensorChanged(SensorEvent sensorEvent) {

			long currentUpdateTime = System.currentTimeMillis();
			// long eventTime =(int)(NS2S*sensorEvent.timestamp);//用自带的可能占用空间更少
			// Log.e("timecompare",currentUpdateTime+" "+eventTime);

			if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
				magneticFieldValues = sensorEvent.values.clone();
			if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
				// if (sensorEvent.sensor.getType() ==
				// Sensor.TYPE_ACCELEROMETER) {
				accelerometerValues = sensorEvent.values.clone();
				// float maxacc= sensorEvent.sensor.getMinDelay();
				// Log.e("log","acc:"+sensorEvent.sensor.getResolution());//0.00390625
				// Log.e("log","Acc: "+sensorEvent.sensor.getMinDelay());
			}
			if (sensorEvent.sensor.getType() == Sensor.TYPE_GRAVITY) {
				gravityValues = sensorEvent.values.clone();

				// sensorEvent.sensor.getMinDelay();
				// Log.e("log","GRAVITY:"+maxgra);
			}
			if (sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
				gyroscopeValues = sensorEvent.values.clone();
				// float maxgy = sensorEvent.sensor.getMinDelay();
				// Log.e("log","Gyr:"+sensorEvent.sensor.getResolution());//0.0107
				// Log.e("log","Gyr: "+sensorEvent.sensor.getMinDelay());
			}

			// calculateOrientation();

			if (currentUpdateTime - begintime > warmup) {// 完成了5s预热
				if (cflag != true) {
				
					correcter.update(wulax);
					axfix = -correcter.getoffset("ax");

					correcter.update(wulay);
					ayfix = -correcter.getoffset("ay");

					correcter.update(wulaz);
					azfix =9.8f-correcter.getoffset("az");

				//	Log.e("correct", "修正值：" + axfix + " "+ ayfix + " " + azfix);
					cflag = true;
					initwp();

				}// 获取修正值，在修正函数就做了取反的操作
				if (currentUpdateTime - lastUpdateTime >= UPTATE_INTERVAL_TIME) {// 正式轮询
					hardware(currentUpdateTime);
					filterall(100);// 过滤当前时间片的传感器波动
					update();
					lastUpdateTime = currentUpdateTime;
					timecount++;
				}
			} else {//

				if (currentUpdateTime - lastUpdateTime >= UPTATE_INTERVAL_TIME) {

					filterall(10);// 过滤当前时间片的传感器波动
					// update();
			//		wuldx.add(dx);
			//		wuldy.add(dy);
			//		wuldz.add(dz);
					
					wulax.add(ax);
					wulay.add(ay);
					wulaz.add(az);
					lastUpdateTime = currentUpdateTime;
					timecount++;
				}

			}
		}

		public void onAccuracyChanged(Sensor sensor, int accuracy) {

		}
	};

	// 将每个独立类的更转移到该函数，并用于实时的数值传递
	public void update() {

		formattime = ft.format(new Date());// 当前时间片统一时钟，用于不同手机之间时间同步
		// slot=0.1s
		long time = lastUpdateTime - begintime;// 软件启动之后的相对时间

		// confirmUpDown(gx, gy, gz);//确定手机朝向
		// 取消过滤
		// filterall();// 过滤当前时间片的传感器波动
		float[] p = new float[7];
		//p[0] = ax + axfix;
		//p[1] = ay + ayfix;
		//p[2] = az + azfix;	
		//关修正
		p[0] = ax;
		p[1] = ay;
		p[2] = az;	
		
		
		p[3] = dx;
		p[4] = dy;
		p[5] = dz;// 如果后期考虑所有传感器修正，改成一个数组就行了
		p[6] = cx;

		// Log.e("core",ay+"");
		md1.update(time, ax, ay);
		orientlog.update(formattime + " " + timecount + " " + time + " " + cx+ " " + Orientation(cx));

		mybump.checkstate(time, dz);// 改进的转向，带具体信息识别
		mybump.updateor(time, cx);// 跟新方向列表
		mywaves.checkstate(time, dz, speed,p);// 新增
		if (mywaves.getresult() != null) {
			Log.e("wavescoming", mywaves.getresult());
			wavelog.update(formattime + " " + timecount + " " + time + " "+ mywaves.getresult());
			mywaves.initresult();
		}
		
		//统计采集
		if(!mywaves.getsli().isEmpty()){			
			//波形内传感器数值输出，时间和波形分离，因为内容较多
			wavesdata1.update(formattime + " " + timecount + " " + time + "\n");
			//Log.e("In-core",mywaves.allsensor2string().size()+" ");
			wavesdata1.update(mywaves.getsli());	
			//统计版信息，用于weka标记
			mywaves.initsli();
		}
		
		if(!mywaves.getsi().isEmpty()){			
			//波形内传感器数值输出，时间和波形分离，因为内容较多
			wavesdata2.update(formattime + " " + timecount + " " + time + "\n");
			wavesdata2.update(mywaves.getsi());	
			//统计版信息，用于weka标记
			mywaves.initsi();
		}
		
		if(!mywaves.getcsli().isEmpty()){			
			//波形内传感器数值输出，时间和波形分离，因为内容较多
			wavesdata3.update(formattime + " " + timecount + " " + time + "\n");
			//Log.e("In-core-cslitest",mywaves.getcsli().size()+"");
			wavesdata3.update(mywaves.getcsli());	
			//统计版信息，用于weka标记
			mywaves.initcsli();
		}
		
		if(!mywaves.getcsi().isEmpty()){			
			//波形内传感器数值输出，时间和波形分离，因为内容较多
			wavesdata4.update(formattime + " " + timecount + " " + time + "\n");
			//Log.e("In-core-cslitest",mywaves.getcsli().size()+"");
			wavesdata4.update(mywaves.getcsi());	
			//统计版信息，用于weka标记
			mywaves.initcsi();
		}
		// 显示的暂时不管了
		/*
		 * cstate.setText(formattime + "\n 当前方向：" + Orientation(cx) + ":" + cx +
		 * "\n 加减速：" + mystate.getaccstate() + " \n   转向：" +mybump.getresult()+
		 * "\n");
		 */
		// cstate.setText(formattime + "\n 当前方向："
		// + Orientation(cx) + ":" + cx +
		// "\n 传感器偏移：x="+ax+"\n y="+ay+"\n z="+(az-10));
		cstate.setText(formattime + ": 加速度：" + ax + " " + ay + " " + az
				+ "\n角速度：" + dx + " " + dy + " " + dz + "\n方向：" + cx);

		senlog.update(formattime + " " + timecount + " " + time + " " + ax
				+ " " + ay + " " + dz + " " + cx + " " + Orientation(cx));
		all.update(formattime + " " + timecount + " " + time + " " + ax + " " + ay + " " + az + " " +dx + " " + dy + " " + dz + " " + cx + " "
				+ Orientation(cx)+" "+ speed);

		if (mybump.getresult() != null) {// 位移判断也添加在此
			Log.e("allin", mybump.getresult());

			Log.e("allin", mybump.getbumptime().toString());
			double[] a = md1.getsimpledistance(mybump.getbumptime().getKey(),
					mybump.getbumptime().getValue());

			// Log.e("allin",a[0]+" "+a[1]); 分别是第一个波和第二个波的检测持续时间
			autobumplog.update(formattime + " " + timecount + " " + time + " "
					+ mybump.getresult() + " " + a[0] + " " + a[1] + " "
					+ speed);
			mybump.init();
		}

	}

	private float calculateOrientation() {
		float[] values = new float[3];
		float[] R = new float[9];
		SensorManager.getRotationMatrix(R, null, accelerometerValues,
				magneticFieldValues);
		SensorManager.getOrientation(R, values);

		// 要经过一次数据格式的转换，转换为度
		float arc = 0;
		float value = (float) Math.toDegrees(values[0]);

		if (values[0] < 0) {// 不加在180附近会有跃变，180<-> -180 ;改了是在360<->0
			arc = value + 359;
		} else
			arc = value;
		// values[0] = (float) Math.toDegrees(values[0]);
		// values[1] = (float) Math.toDegrees(values[1])*10/10;
		// values[2] = (float) Math.toDegrees(values[2])*10/10;
		return arc;
		// return value;
	}

	// 通过手动将行使情况输入到对应log中
	private void logbyhand() {

		mButton = (Button) findViewById(R.id.acc);// 加速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest1);
				handstatelog
						.update(formattime + " " + timecount + " " + mTest1);
			}
		});
		mButton = (Button) findViewById(R.id.dec);// 减速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest2);
				handstatelog
						.update(formattime + " " + timecount + " " + mTest2);
			}
		});
		mButton = (Button) findViewById(R.id.leftturn);// 左转
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest3);
				handstatelog
						.update(formattime + " " + timecount + " " + mTest3);
			}
		});
		mButton = (Button) findViewById(R.id.rightturn);// 右转
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest4);
				handstatelog
						.update(formattime + " " + timecount + " " + mTest4);
			}
		});
		mButton = (Button) findViewById(R.id.Uturn);// 掉头
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				// Log.i("log", mTest5);
				handstatelog
						.update(formattime + " " + timecount + " " + mTest5);
			}
		});
		mButton = (Button) findViewById(R.id.leftlane);// 加速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest1);
				handstatelog
						.update(formattime + " " + timecount + " " + mTest6);
			}
		});

		mButton = (Button) findViewById(R.id.rightlane);// 加速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest1);
				handstatelog
						.update(formattime + " " + timecount + " " + mTest7);
			}
		});
	}

	private void initSensors() {

		mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		// getDefaultSensor方法的参数值，
		// 例如，注册加速传感器可以使用Sensor.TYPE_ACCELEROMETER。在Sensor类中还定义了很多传感器常量，
		// 但要根据手机中实际的硬件配置来注册传感器。如果手机中没有相应的传感器硬件，就算注册了相应的传感器也不起任何作用。
		// 注册四种传感器
		mAccelerometer = mSensorManager
				.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);// 加速度
																// TYPE_LINEAR_ACCELERATION
		// mGravity = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);// 重力
		mGyroscope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);// 角速度
		mCompass = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);// 方向

		mSensorManager.registerListener(myListener, mAccelerometer, 3);// SENSOR_DELAY_FASTEST=0(0),
																		// SENSOR_DELAY_NORMAL=3(200),
																		// SENSOR_DELAY_GAME=1(20)
		mSensorManager.registerListener(myListener, mCompass, 3);// SENSOR_DELAY_NORMAL
		// mSensorManager.registerListener(myListener, mGravity,
		// SensorManager.SENSOR_DELAY_NORMAL);
		mSensorManager.registerListener(myListener, mGyroscope, 3);
		// 这三个传感器是测量值变化就能够度量的，没有最低时间间隔
		// Log.e("accdelay"," "+mAccelerometer.getMinDelay());
		// Log.e("gyr"," "+mGyroscope.getMinDelay());
		// Log.e("com"," "+mCompass.getMinDelay());
		cstate = (TextView) findViewById(R.id.cstate);
		cstate.setText("4in1");
	}

	@Override
	protected void onResume() {

		super.onResume();
	}

	//
	protected void onPause() {
		super.onPause();
		mSensorManager.unregisterListener(myListener);

	}

	// 确定手机方向
	public void onAccuracyChanged(Sensor sensor, int accuracy) {

	}

	// 传入参数应为gravity三轴，后期考虑非平面
	public void confirmUpDown(float x, float y, float z) {
		if (z > 7.5 && x < 3 && y < 3) {
			up = "a";
		} else if (z < -7.5 && x < 3 && y < 3) {
			up = "b";
		} else if (x > 7.5 && z < 3 && y < 3) {
			up = "c";
		} else if (x < -7.5 && z < 3 && y < 3) {
			up = "d";
		} else if (y > 7.5 && x < 3 && z < 3) {
			up = "e";
		} else if (y < -7.5 && x < 3 && z < 3) {
			up = "f";
		}

	}

	// 只过滤小数点。参数：@待精确的值@精确位数
	public float filter1(float value, int accuracy) {

		return (float) Math.round(value * accuracy) / accuracy;// 精确到小数点后2位,方便计算
	}

	public String Orientation(float cx) {
		String s = "";
		if (cx <= 22.5 || cx > 337.5)
			s = "北";// north
		if (cx <= 337.5 && cx > 292.5)
			s = "西北";// northwest
		if (cx >= 247.5 && cx < 292.5)
			s = "西";// west
		if (cx >= 202.5 && cx < 247.5)
			s = "西南";// southwest
		if (cx >= 157.5 && cx < 202.5)
			s = "南";// south
		if (cx >= 112.5 && cx < 157.5)
			s = "东南";// southeast
		if (cx >= 67.5 && cx < 112.5)
			s = "东";// east
		if (cx >= 22.5 && cx < 67.5)
			s = "东北";// northeast
		return s;
	}

	// String check_info="";
	// @SuppressWarnings("deprecation")
	public void onSensorChanged(SensorEvent event) {

	}

	// 触摸事件有 按下，滑动，和放开三类，仅讲一次放开作为事件的计数
	// 另外只记录对屏幕的接触，没有加入对按钮，对其他实体按键和弹出后对其他软件的坚听。
	public boolean onTouchEvent(MotionEvent event) {

		// 获得触摸的坐标
		// float x = event.getX();
		// float y = event.getY();

		switch (event.getAction()) {
		// 触摸屏幕时刻
		case MotionEvent.ACTION_DOWN:
			// Log.e("screen","down");
			break;
		// 触摸并移动时刻
		case MotionEvent.ACTION_MOVE:
			// Log.e("screen","move");
			break;
		// 终止触摸时刻
		case MotionEvent.ACTION_UP:
			mstatis.updateuse();
			// Log.e("screen","up");
			break;
		}
		return true;
	}

	// 将错误码映射到
	private String locastate(int code) {
		switch (code) {
		case (61):
			gpsav = true;
			return "GPS定位结果";
		case (161):
			gpsav = false;
			return "网络定位结果";
		default:
			gpsav = false;
			return "无法定位";
		}
	}

	// 定位相关，包括经纬度、速度、加速度的相关信息
	public class MyLocationListener implements BDLocationListener {

		@Override
		public void onReceiveLocation(BDLocation location) {// 显示出现的信息
			// Receive Location
			StringBuffer sb = new StringBuffer(256);
			sb.append("时间 ：");
			sb.append(location.getTime());// 检查gps是否在执行，后期可剔除
			sb.append("\n定位类型: ");
			sb.append(locastate(location.getLocType()));
			sb.append("\n经度: ");
			sb.append(location.getLatitude());// double类型
			sb.append("\n纬度: ");
			sb.append(location.getLongitude());// double类型
			// sb.append("\nradius : ");
			// sb.append(location.getRadius());
			if (location.getLocType() == BDLocation.TypeGpsLocation) {

				sb.append("\n速度 : ");
				sb.append(location.getSpeed());// km/h
				sb.append("\n卫星数 : ");
				sb.append(location.getSatelliteNumber());
				// sb.append("\ndirection : ");
				sb.append("\n地址 : ");
				sb.append(location.getAddrStr());
				// sb.append(location.getDirection());

			} else if (location.getLocType() == BDLocation.TypeNetWorkLocation) {
				sb.append("\n地址 : ");
				sb.append(location.getAddrStr());
				// 运营商信息，不重要kill
				// sb.append("\noperationers : ");
				// sb.append(location.getOperators());
			}
			logMsg(sb.toString());

			mgs.updategps(location.getLocType());// 针对
			// gpsspeed(location.getSpeed());
			if (location.getLocType() == 61) {// 仅当返回值为61时，返回的是gps定位结果

				mstatis.updategpsa();// gps有效
				mstatis.updatesatellite(location.getSatelliteNumber());// 更新搜星数量统计
				long currenttime = System.currentTimeMillis();
				long timeslot = currenttime - begintime;// mgs内部有保存上一个时间片的字段，所以只需要系统启动后的相对时间
				// 增加了对接口获取数值的判断，如果有就更新，没有就0
				if (location.hasSpeed())
					speed = location.getSpeed();
				else if (lspeed < 10)
					speed = -1;
				String state = mgs.update(timeslot, speed);
				// Gps速度状态栏刷新
				if (state != null) {
					gps_speed.setText(location.getTime() + "\n" + timeslot
							+ "\n速度：" + (int) speed + "km/h\n加速度 "
							+ mgs.getacc() + "m/s^2\n" + state);
				} else {
					gps_speed.setText(location.getTime() + "\n" + timeslot
							+ "\n当前未返回速度！");
				}
				mydistance.updatecoord(location.getLatitude(),
						location.getLongitude());
				mydistance.updatecoordbys(location.getLatitude(),
						location.getLongitude());
				rp.updategpsl(location.getLatitude(), location.getLongitude());
				gpsllog.update(location.getTime() + " " + timeslot + " "
						+ location.getLatitude() + " "
						+ location.getLongitude() + " "
						+ location.getSatelliteNumber());// 输入到日志的信息
				gpsslog.update(location.getTime() + " " + timeslot + " "
						+ speed + " " + mgs.getacc());
				// 更新gps距离，gpstimer误差在秒级，这样来计算距离可能有问题，精确度不够，不过gps定位的更新最小间隔是1s，无法提高
				// md2.updategps(gpstimer,location.getLatitude(),location.getLongitude());
				lspeed = speed;

			} else {
				mstatis.updategpsl();// gps失效

			}
		}

	}

	public void logMsg(String str) {
		try {
			if (LocationResult != null)
				LocationResult.setText(str);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void onDestroy() {
		super.onDestroy();
		// Log.e("existtest", "" + System.currentTimeMillis());
		senlog.outputlast();// 最后的列表可能不到1000，所以结束时强制输出，以免丢失
		orientlog.outputlast();

		handstatelog.outputlast();
		gpsllog.outputlast();
		gpsslog.outputlast();
		autobumplog.outputlast();
		wavelog.outputlast();
		drivinglog.update(mywaves.getscores());
		drivinglog.outputlast();
		mgs.updateinend();
		statisticlog.update(mstatis.output());
		statisticlog.outputlast();
		statisticlog.init();
		hardwarelog.outputlast();
		all.outputlast();
		wavesdata1.outputlast();
		wavesdata2.outputlast();
		wavesdata3.outputlast();
		wavesdata4.outputlast();
		rp.getinflexion();
		unregisterReceiver(batteryLevelRcvr);// 注销电池通知
	}

	public static String getMaxCpuFreq() {
		String result = "";
		ProcessBuilder cmd;
		try {
			String[] args = { "/system/bin/cat",
					"/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq" };
			cmd = new ProcessBuilder(args);
			Process process = cmd.start();
			InputStream in = process.getInputStream();
			byte[] re = new byte[24];
			while (in.read(re) != -1) {
				result = result + new String(re);
			}
			in.close();
		} catch (IOException ex) {
			ex.printStackTrace();
			result = "N/A";
		}
		return result.trim();
	}

	public static String getCurCpuFreq() {
		String result = "N/A";
		try {
			FileReader fr = new FileReader(
					"/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
			BufferedReader br = new BufferedReader(fr);
			String text = br.readLine();
			result = text.trim();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	// 当前时间
	public void hardware(long ct) {
		if (ct - lasthw > hardwareupdatef) {
			hardwarelog.update((int) ((ct - begintime) / 1000) + "   "
					+ Integer.valueOf(getCurCpuFreq()).intValue()
					+ "  battery： " + batterylevel);
			Log.e("core-hardware", (int) ((ct - begintime) / 1000) + "   "
					+ Long.valueOf(getCurCpuFreq()).intValue() + "  电池： "
					+ batterylevel);
			lasthw = ct;
		}
	}

	// 电池相关
	private BroadcastReceiver batteryLevelRcvr;
	private IntentFilter batteryLevelFilter;
	private int batterylevel = 0;

	// 函数
	private void monitorBatteryState() {
		batteryLevelRcvr = new BroadcastReceiver() {

			public void onReceive(Context context, Intent intent) {
				batterylevel = 0;

				StringBuilder sb = new StringBuilder();
				int rawlevel = intent.getIntExtra("level", -1);
				int scale = intent.getIntExtra("scale", -1);
				int status = intent.getIntExtra("status", -1);
				int health = intent.getIntExtra("health", -1);
				int level = -1; // percentage, or -1 for unknown

				batterylevel = rawlevel;

				if (rawlevel >= 0 && scale > 0) {
					level = (rawlevel * 100) / scale;
				}
				sb.append("The phone");
				if (BatteryManager.BATTERY_HEALTH_OVERHEAT == health) {
					sb.append("'s battery feels very hot!");
				} else {
					switch (status) {
					case BatteryManager.BATTERY_STATUS_UNKNOWN:
						sb.append("no battery.");
						break;
					case BatteryManager.BATTERY_STATUS_CHARGING:
						sb.append("'s battery");
						if (level <= 33)
							sb.append(" is charging, battery level is low"
									+ "[" + level + "]");
						else if (level <= 84)
							sb.append(" is charging." + "[" + level + "]");
						else
							sb.append(" will be fully charged.");
						break;
					case BatteryManager.BATTERY_STATUS_DISCHARGING:
					case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
						if (level == 0)
							sb.append(" needs charging right away.");
						else if (level > 0 && level <= 33)
							sb.append(" is about ready to be recharged, battery level is low"
									+ "[" + level + "]");
						else
							sb.append("'s battery level is" + "[" + level + "]");
						break;
					case BatteryManager.BATTERY_STATUS_FULL:
						sb.append(" is fully charged.");
						break;
					default:
						sb.append("'s battery is indescribable!");
						break;
					}
				}
				sb.append(' ');
				// Log.e("batteryinfo",sb.toString());
			}
		};
		batteryLevelFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		registerReceiver(batteryLevelRcvr, batteryLevelFilter);
	}

}
