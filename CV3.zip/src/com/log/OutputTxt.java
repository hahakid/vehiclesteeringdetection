package com.log;
import java.lang.*;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

public class OutputTxt {
	
    private boolean mHasSD = false; 
 
    private String mFileParentPath;
    Context context;
	//public OutputTxt(Context context) {
     public OutputTxt() {
		
		mHasSD = Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED); 
		
		if (mHasSD) {
			//如果存在SD存储卡，会首先将数据存储到SD卡中，下面一句用于获取SD卡路径
			mFileParentPath = Environment.getExternalStorageDirectory().getPath();
		} else {
			//如果不存在SD卡，会选择将文件存储到工程目录下面
			mFileParentPath = this.context.getFilesDir().getPath(); 
		}
	}
	
	
	
	// 生成文件夹
	public void makeRootDirectory(String dirPath) {
	    File file = null;
	    try {
	        file = new File(mFileParentPath + "/" + dirPath);
	        if (!file.exists()) {
	            file.mkdir();
	        }
	    } catch (Exception e) {
	        Log.i("error:", e+"");
	    }
	}
	
	
	// 生成文件
	public String makeFilePath(String dirPath, String fileName) {
		
	    File file = null;
	    String filePath = mFileParentPath + "/" + dirPath + "/" + fileName;
	    makeRootDirectory(dirPath);
	    try {
	        file = new File(filePath);
	        if (!file.exists()) {
	            file.createNewFile();
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return filePath;
	}
	
	// 一个逐行将生成信息输出到文本的函数
		public static void writeline(String file, String a) {
			try {
				FileWriter fw = new FileWriter(file, true);
				BufferedWriter bw = new BufferedWriter(fw);
				String writeoneline = a;

				bw.write(writeoneline);
				// System.out.println(writeoneline);
				bw.newLine();// 写入一个行分隔符。

				bw.flush();
				bw.close();
				fw.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}// ///////////////////////////////////////////////////

		//批量写入
		public static void writeline(String file, ArrayList<String> sl) {
			
			try {
				
				FileWriter fw = new FileWriter(file, true);
				BufferedWriter bw = new BufferedWriter(fw);
				
				for(int i=0;i<sl.size();i++){
					//Log.e("log","write");
					String writeoneline = sl.get(i);
				bw.write(writeoneline);
				// System.out.println(writeoneline);
				bw.newLine();// 写入一个行分隔符。
				bw.flush();
				}
				bw.close();
				fw.close();
			
			} catch (IOException e) {
				e.printStackTrace();
			}
		}// ///////////////////////////////////////////////////
		
}
