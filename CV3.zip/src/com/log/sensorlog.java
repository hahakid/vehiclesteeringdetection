package com.log;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.util.Log;
//暂存字符串，然后到阈值输出
public class sensorlog {
	
	private String logname;
	private String filepath;
	private int opl=1000;//每1000条数据进行一次输出 out_put_length
	private OutputTxt mOutPutTxt;
	private ArrayList<String> buffer;
	private String path;
	
	
	//初始化
	public void init(){		
		buffer=new ArrayList<String>();
	}
		
	public void initfile(String afilepath,String alogname){
		//Log.e("log","initlog");
		init();
		this.logname=alogname;
		this.filepath=afilepath;
		SimpleDateFormat fd = new SimpleDateFormat("yyyyMMdd "); 
		mOutPutTxt = new OutputTxt();
		path=mOutPutTxt.makeFilePath(filepath, fd.format(new Date())+logname+".txt");
		//生成完毕之后初始化一下		
	}
	
	//单条更新
	public void update(String s){
		if(buffer.size()<opl){buffer.add(s);}//不够总数时继续添加
		else {
		mOutPutTxt.writeline(path,buffer);//输出完毕后
		buffer.clear();
		buffer.add(s);//再添加本条
		}
	}
	
	//多条更新，由于是批量，所以直接写入文件
	public void update(ArrayList<String> s){
		//if(!s.isEmpty()&&s!=null)mOutPutTxt.writeline(path,s);//输出完毕后	
		//mOutPutTxt.writeline(path,s);
		if(buffer.size()<opl){buffer.addAll(s);}//不够总数时继续添加
		else {
		mOutPutTxt.writeline(path,buffer);//输出完毕后
		buffer.clear();
		buffer.addAll(s);//再添加本条
		}
	}
	
	
	//强制输出，在条目不到opl时，输出，用在程序被终止时
	public void outputlast(){
		if(buffer.size()>0)
			mOutPutTxt.writeline(path,buffer);
	}
	
	//获取文件大小（单位B）,long所能表示的最大长度9223372036854775807B=8388607TB基本不会溢出
	public long getfilesize(){
		File f=new File(path);
		if (f.exists() && f.isFile()){  
	        return f.length();  
	    }else{  
	       return 0;  
	    }  
	}
	
}
