package com.route;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.log.OutputTxt;
import com.util.Tuple;

public class nodefromfile {
	private static ArrayList<Tuple<Double, Double>> gl = new ArrayList<Tuple<Double, Double>>();
	// 保存全部gps地理信息

	static double minangle = 180;
	static double maxangle = 0;


	
	// 初始化缓存不够，从文件读取
		public static void readFileByLines(String fileName) {
			
			double[][] a = null;
			File file = new File(fileName);
			BufferedReader reader = null;
			try {
				// System.out.println("以行为单位读取文件内容，一次读一整行：");
				reader = new BufferedReader(new FileReader(file));
				String tempString = null;
				int line = 1;
				// 一次读入一行，直到读入null为文件结束
				while ((tempString = reader.readLine()) != null) {
					// 显示行号
					int i = 0, j = 0, k = 0, count = 0;
					k = tempString.length();
					for (int z = 0; z < k; z++) {
						if (tempString.charAt(z) == ' ') {
							count++;
							if (count == 3)
								i = z;
							if (count == 4)
								j = z;
							// if(count==3)k=z;
						}

					}
					gl.add(new Tuple<Double, Double>(Double.parseDouble(tempString
							.substring(i, j)), Double.parseDouble(tempString
							.substring(j, k))));
					line++;
				}
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e1) {
					}
				}
			}

		}
	
	
	// 一个逐行将生成信息输出到文本的函数
	public static void writeline(String file, String a) {
		try {
			FileWriter fw = new FileWriter(file, true);
			BufferedWriter bw = new BufferedWriter(fw);
			String writeoneline = a;

			bw.write(writeoneline);
			bw.newLine();// 写入一个行分隔符。

			bw.flush();
			bw.close();
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 通过三个点计算夹角 @第一个点e @角点s@ 第三个点n
	// public static double getangle(double x1, double y1, double x2, double y2,
	public static double getangle(double x2, double y2, double x1, double y1,
			double x3, double y3) {
		double arc = (Math.atan((y3 - y2 + 0.00001) / (x3 - x2 + 0.00001)) - Math
				.atan((y1 - y2 + 0.00001) / (x1 - x2 + 0.00001)))
				/ Math.PI
				* 180;// 返回绝对值

		if (arc >= 0)
			return arc;
		else
			return (180 + arc);

	}

	// 获取转折点,参数：@经度@纬度@阈值@步长
	public ArrayList<Tuple<Double, Double>> getpoint(
			ArrayList<Tuple<Double, Double>> gl, double threshold, int instep) {
		// ArrayList<Integer> point = new ArrayList<Integer>();//存结果
		ArrayList<Tuple<Double, Double>> pointlist = new ArrayList<Tuple<Double, Double>>();// 存结果
		int s = 0, e = 1, n = 2;// 遍历下标，e-s-n 为边角边∠esn
		int step = instep, total = gl.size();// 总数
		double xf, xs, xt, yf, ys, yt, lastangle = 0;
		int count = 0;// 步长

		while (n < total - 1) {
			// 获取当前夹角
			double angle = getangle(gl.get(e).getKey(), gl.get(e).getValue(),
					gl.get(s).getKey(), gl.get(s).getValue(), gl.get(n)
							.getKey(), gl.get(n).getValue());// 增加函数getmaxangle
			// statangle(angle);
			if (angle < threshold || angle > (180 - threshold)) { // 夹角太大
				// if ((angle <
				// threshold||angle>(180-threshold))||Math.abs(angle-lastangle)<20)
				// { // System.err.println("1: "+angle);
				// if (angle < threshold){
				lastangle = angle;
				e = e + step;
				n = n + step;
			}// 低于阈值 边点后移
			else {
				statangle(angle);
				pointlist.add(gl.get(s));
				s = e;
				e = e + step;
				n = n + step;
				count++;
				lastangle = angle;
			}
		}
		// point.add(total-1);
		pointlist.add(gl.get(total - 1));
		return pointlist;
	}

	// 统计最大最小的夹角
	public void statangle(double angle) {
		if (minangle > angle)
			minangle = angle;
		if (maxangle < angle)
			maxangle = angle;
	}

	public double[] listtoarray(ArrayList<Double> a) {
		double[] newa = new double[a.size()];
		for (int i = 0; i < a.size(); i++) {
			newa[i] = a.get(i).doubleValue();

		}
		return newa;
	}

	
	public String getpath(){
		String path;
		SimpleDateFormat fd = new SimpleDateFormat("yyyyMMdd "); 
		path="./atest/"+fd.format(new Date())+"gpsl.txt";
		return path;
	}
	
	// 通过两次过滤获取拐点坐标
	public ArrayList<Tuple<Double, Double>> getinflexion() {
		//通过读取外部文件，来获取坐标，而非实时更新，只读取当天的gpsltxt文件
		
		readFileByLines(getpath());
		
		
		if(gl.isEmpty()){return null;}
		ArrayList<Tuple<Double, Double>> r1 = getpoint(gl, 10, 2);// 第一次过滤
		ArrayList<Tuple<Double, Double>> r2 = new ArrayList<Tuple<Double, Double>>();

		for (int i = 0; i < r1.size() - 1; i++) {// 过滤相同坐标
			if (!r1.get(i).getKey().equals(r1.get(i + 1).getKey())
					&& !r1.get(i).getValue().equals(r1.get(i + 1).getValue())) {
				r2.add(r1.get(i));
			}
		}
		r2.add(r1.get(r1.size() - 1));// 插入最后一个节点

		ArrayList<Tuple<Double, Double>> r3 = getpoint(r2, 5, 1);
		output(r3);//做一个文本输出
		return r3;
	}

	public void output(ArrayList<Tuple<Double, Double>> l){
		String ot="atest/rp.txt";
		for(int i=0;i<l.size();i++){
			writeline(ot, i + " " + l.get(i).getKey() + " " + l.get(i).getValue());	
		}
	}
	
}
