package com.route;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import android.util.Log;

import com.util.Tuple;

//根据gps坐标点，寻找线路拐点，最终输出拐点坐标集
//百度sdk对gps坐标有自己的2维数据结构，可考虑统一数据结构

public class routepoints {

	private static ArrayList<Tuple<Double, Double>> gl = new ArrayList<Tuple<Double, Double>>();
	// 保存全部gps地理信息

	static double minangle = 180;
	static double maxangle = 0;

	// 更新gps 的坐标
	public void updategpsl(double lat, double lon) {
		Tuple<Double, Double> k = new Tuple<Double, Double>(lat, lon);
		gl.add(k);
	}


	// 一个逐行将生成信息输出到文本的函数
	public static void writeline(String file, String a) {
		try {
			FileWriter fw = new FileWriter(file, true);
			BufferedWriter bw = new BufferedWriter(fw);
			String writeoneline = a;

			bw.write(writeoneline);
			bw.newLine();// 写入一个行分隔符。

			bw.flush();
			bw.close();
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 通过三个点计算夹角 @第一个点e @角点s@ 第三个点n
	// public static double getangle(double x1, double y1, double x2, double y2,
	public static double getangle(double x2, double y2, double x1, double y1,
			double x3, double y3) {
		double arc = (Math.atan((y3 - y2 + 0.00001) / (x3 - x2 + 0.00001)) - Math
				.atan((y1 - y2 + 0.00001) / (x1 - x2 + 0.00001)))
				/ Math.PI
				* 180;// 返回绝对值

		if (arc >= 0)
			return arc;
		else
			return (180 + arc);

	}

	// 获取转折点,参数：@经度@纬度@阈值@步长
	public ArrayList<Tuple<Double, Double>> getpoint(
			ArrayList<Tuple<Double, Double>> gl, double threshold, int instep) {
		// ArrayList<Integer> point = new ArrayList<Integer>();//存结果
		ArrayList<Tuple<Double, Double>> pointlist = new ArrayList<Tuple<Double, Double>>();// 存结果
		int s = 0, e = 1, n = 2;// 遍历下标，e-s-n 为边角边∠esn
		int step = instep, total = gl.size();// 总数
		double xf, xs, xt, yf, ys, yt, lastangle = 0;
		int count = 0;// 步长

		while (n < total - 1) {
			// 获取当前夹角
			double angle = getangle(gl.get(e).getKey(), gl.get(e).getValue(),
					gl.get(s).getKey(), gl.get(s).getValue(), gl.get(n)
							.getKey(), gl.get(n).getValue());// 增加函数getmaxangle
			// statangle(angle);
			if (angle < threshold || angle > (180 - threshold)) { // 夹角太大
				// if ((angle <
				// threshold||angle>(180-threshold))||Math.abs(angle-lastangle)<20)
				// { // System.err.println("1: "+angle);
				// if (angle < threshold){
				lastangle = angle;
				e = e + step;
				n = n + step;
			}// 低于阈值 边点后移
			else {
				statangle(angle);
				pointlist.add(gl.get(s));
				s = e;
				e = e + step;
				n = n + step;
				count++;
				lastangle = angle;
			}
		}
		// point.add(total-1);
		pointlist.add(gl.get(total - 1));
		return pointlist;
	}

	// 统计最大最小的夹角
	public void statangle(double angle) {
		if (minangle > angle)
			minangle = angle;
		if (maxangle < angle)
			maxangle = angle;
	}

	public double[] listtoarray(ArrayList<Double> a) {
		double[] newa = new double[a.size()];
		for (int i = 0; i < a.size(); i++) {
			newa[i] = a.get(i).doubleValue();

		}
		return newa;
	}

	// 通过两次过滤获取拐点坐标
	public ArrayList<Tuple<Double, Double>> getinflexion() {
		if(gl.isEmpty()){
			Log.e("routepoints","no node");
			return null;}
		ArrayList<Tuple<Double, Double>> r1 = getpoint(gl, 10, 2);// 第一次过滤
		ArrayList<Tuple<Double, Double>> r2 = new ArrayList<Tuple<Double, Double>>();

		for (int i = 0; i < r1.size() - 1; i++) {// 过滤相同坐标
			if (!r1.get(i).getKey().equals(r1.get(i + 1).getKey())
					&& !r1.get(i).getValue().equals(r1.get(i + 1).getValue())) {
				r2.add(r1.get(i));
			}
		}
		r2.add(r1.get(r1.size() - 1));// 插入最后一个节点

		ArrayList<Tuple<Double, Double>> r3 = getpoint(r2, 5, 1);
		output(r3);//做一个文本输出
		return r3;
	}

	public void output(ArrayList<Tuple<Double, Double>> l){
		String ot="atest/rp.txt";
		for(int i=0;i<l.size();i++){
			writeline(ot, i + " " + l.get(i).getKey() + " " + l.get(i).getValue());	
		}
	}
	
	// 测试用
	/*
	 * public void main(String[] arg) { String input =
	 * "G:/博士期间/智能车/route/gps.txt"; String output =
	 * "G:/博士期间/智能车/route/resultgps.txt"; // G:\博士期间\智能车\route
	 * readFileByLines(input);
	 * //System.out.println("--------------------------------------------------"
	 * ); ArrayList<Tuple<Double, Double>> mid = getpoint(gl, 10, 2);// 使用短步长+多次
	 * //System.out.println(mid.size()); gl.clear(); //
	 * l1=gl.size();l2=mid.size(); int k = 0; for (int i = 0; i < mid.size() -
	 * 1; i++) { if (!mid.get(i).getKey().equals(mid.get(i + 1).getKey()) &&
	 * !mid.get(i).getValue().equals(mid.get(i + 1).getValue())) {
	 * gl.add(mid.get(i)); } } gl.add(mid.get(mid.size() - 1));
	 * 
	 * 
	 * mid = getpoint(gl, 5, 1); gl.clear(); System.out.println(mid.size()); for
	 * (int i = 0; i < mid.size() - 1; i++) { if
	 * (!mid.get(i).getKey().equals(mid.get(i + 1).getKey()) &&
	 * !mid.get(i).getValue().equals(mid.get(i + 1).getValue())) {
	 * writeline(output, k + " " + mid.get(i).getKey() + " " +
	 * mid.get(i).getValue()); k++; gl.add(mid.get(i)); } }
	 * gl.add(mid.get(mid.size() - 1));
	 * 
	 * writeline(output, k + " " + mid.get(mid.size() - 1).getKey() + " " +
	 * mid.get(mid.size() - 1).getValue());
	 * 
	 * // for(int i=ss.length;i>0;i--)mid.remove(ss[i]);
	 * 
	 * System.out.println("done"); }
	 */
}
