package com.route;

import java.util.ArrayList;
import java.util.List;

import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.map.PolylineOptions;
import com.baidu.mapapi.map.TextOptions;
import com.baidu.mapapi.model.LatLng;
import com.drivingpattern.R;
import com.util.Tuple;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class basemap extends Activity {

	MapView mMapView = null;
	BaiduMap mBaiduMap;
	// UI相关
	Button resetBtn;
	Button clearBtn;
	routepoints rp=new routepoints();
	nodefromfile nff=new nodefromfile();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 在使用SDK各组件之前初始化context信息，传入ApplicationContext
		// 注意该方法要再setContentView方法之前实现
		// SDKInitializer.initialize(getApplicationContext());
		setContentView(R.layout.basemap);
		// 获取地图控件引用
		mMapView = (MapView) findViewById(R.id.bmapView);
		
		mBaiduMap = mMapView.getMap();
		// UI初始化
		clearBtn = (Button) findViewById(R.id.cbutton);
		resetBtn = (Button) findViewById(R.id.rbutton);

		OnClickListener clearListener = new OnClickListener() {
			public void onClick(View v) {
				clearClick();
			}
		};
		OnClickListener restListener = new OnClickListener() {
			public void onClick(View v) {
				resetClick();
			}
		};

		clearBtn.setOnClickListener(clearListener);
		resetBtn.setOnClickListener(restListener);

		// 界面加载时添加绘制图层
	//	addCustomElementsDemo();
		//自定义绘制在此添加
	//	plotrout(testdata(),"r1");//使用测试数据绘制
		plotrout(rp.getinflexion(),"");
		
		
	//	plotrout(nff.getinflexion(),"r3");	//读取日志文件绘制
	}


	//测试使用数据，后期可删除
	public ArrayList<Tuple<Double, Double>> testdata(){
		ArrayList<Tuple<Double, Double>> kkk=new ArrayList<Tuple<Double, Double>>();		
		kkk.add(new Tuple<Double,Double>(31.022207,112.626103));
		kkk.add(new Tuple<Double,Double>(31.022262,112.625549));
		kkk.add(new Tuple<Double,Double>(31.022305,112.62524));
		kkk.add(new Tuple<Double,Double>(31.022382,112.624994));
		kkk.add(new Tuple<Double,Double>(31.022449,112.624899));
		kkk.add(new Tuple<Double,Double>(31.022623,112.624782));
		kkk.add(new Tuple<Double,Double>(31.022953,112.624709));
		kkk.add(new Tuple<Double,Double>(31.023202,112.624676));
		kkk.add(new Tuple<Double,Double>(31.026351,112.624436));
		kkk.add(new Tuple<Double,Double>(31.033078,112.623929));
		kkk.add(new Tuple<Double,Double>(31.042531,112.623487));
		kkk.add(new Tuple<Double,Double>(31.069499,112.626606));
		kkk.add(new Tuple<Double,Double>(31.094833,112.633401));
		kkk.add(new Tuple<Double,Double>(31.107818,112.633626));
		kkk.add(new Tuple<Double,Double>(31.111555,112.633089));
		kkk.add(new Tuple<Double,Double>(31.116848,112.631203));
		kkk.add(new Tuple<Double,Double>(31.126798,112.626));
		kkk.add(new Tuple<Double,Double>(31.130132,112.623025));
		kkk.add(new Tuple<Double,Double>(31.131811,112.620871));
		kkk.add(new Tuple<Double,Double>(31.134424,112.616444));
		kkk.add(new Tuple<Double,Double>(31.134874,112.61593));
		kkk.add(new Tuple<Double,Double>(31.135121,112.61571));
		kkk.add(new Tuple<Double,Double>(31.151233,112.60805));
		return kkk;
	}

	public int plotrout(ArrayList<Tuple<Double, Double>> gl,String routename) {
		if(gl==null){return 0;}
		LatLng start, end;
		int length = gl.size();// 总长度
		// 创建折线
		List<LatLng> points = new ArrayList<LatLng>();
		for (int i = 0; i < length; i++) {
			Tuple<Double, Double> p = gl.get(i);
			LatLng point = new LatLng(p.getKey(), p.getValue());
			points.add(point);
		}
		// 绘制折线
		OverlayOptions ooPolyline = new PolylineOptions().width(5)
				.color(0xAA00FF00).points(points);
		mBaiduMap.addOverlay(ooPolyline);

		// 绘制起点，终点
		start = new LatLng(gl.get(0).getKey(), gl.get(0).getValue());
		end = new LatLng(gl.get(length - 1).getKey(), gl.get(length - 1)
				.getValue());

		OverlayOptions startText = new TextOptions().bgColor(0xAAFFFF00)
				.fontSize(24).fontColor(0xFFFF00FF).text("起点"+routename).rotate(-30)
				.position(start);
		OverlayOptions endText = new TextOptions().bgColor(0xAAFFFF00)
				.fontSize(24).fontColor(0xFFFF00FF).text("终点").rotate(-30)
				.position(end);

		mBaiduMap.addOverlay(startText);
		mBaiduMap.addOverlay(endText);
		return 1;
	}

	
	public void resetClick() {
		// 添加绘制元素
		// addCustomElementsDemo();
	//	plotrout(testdata(),"r1");
		plotrout(rp.getinflexion(),"");
	//	plotrout(nff.getinflexion(),"r3");	
	}
	
	public void clearClick() {
		// 清除所有图层
		mMapView.getMap().clear();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		// 在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
		mMapView.onDestroy();
	}

	@Override
	protected void onResume() {
		super.onResume();
		// 在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
		mMapView.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
		// 在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
		mMapView.onPause();
	}

}
