package com.speed;

import java.util.ArrayList;

import android.util.Log;

import com.util.Tuple;
import com.util.statistic;

public class GPSspeed {// km/h or m/s
	// update frequency is 1Hz
	float lastspeed = 0;
	String laststate;
	float acc = 0;// 加速度是根据gps速度计算的，与传感器无关

	static float maxspeed = 0;
	static float minspeed = 0;
	static float average = 0;
	static float maxacc = 0;
	int count = 0;
	static float slowtimer = 0;// 记录车速低于2km/s的时间
	boolean isslow = false;

	long lt = 0;// 上个时间片
	ArrayList<Tuple<Long, float[]>> recorder = new ArrayList<Tuple<Long, float[]>>();
	private String state = null;
	// 状态
	final String stopstate = "停车";
	final String accstate = "加速";
	final String decstate = "减速";
	final String back = "后退";
	final String ahead = "前进";
	final String constant = "匀速";
	statistic as = new statistic();// 加减速统计
	long begin = 0;
	boolean isGPSon = false;

	// gps有效用gps gps失效用传感器
	public void updategps(int i) {
		if (i == 61)
			isGPSon = true;
		else
			isGPSon = false;
	}

	// 更新统计速度值
	public void updatestatistic(float s, float a) {
		if (a > maxspeed)
			maxacc = a;
		if (s > maxspeed)
			maxspeed = s;
		if (s > 0 && s < minspeed)
			minspeed = s;
		average += s;
		count++;
		// 根据速度判断是否处于低速慢行状态
		if (s > 2)
			isslow = false;
		else
			isslow = true;
		slowtimer();
	}

	// 低速慢行计时器
	public void slowtimer() {
		// 处于慢行状态，开始记录时间
		if (isslow)
			begin = System.currentTimeMillis();
		else {
			if (begin != 0) {
				long end = System.currentTimeMillis();
				slowtimer += (end - begin) / 1000;
				begin = 0;
			}
		}

	}

	
	
	
	// 事实对各种事件次数等进统计
/*	public String update(long t, float speed) {
		updaterecorder(t, speed, acc);// 先更新

		String state;
		float detaspeed = speed - lastspeed;
		long detat = t - lt;
		acc = (float) (1000 * (detaspeed * 3.6) / (detat));
		updatestatistic(speed, acc);

		if (speed == 0) {// 停车情况下，正加速度，为加速前进，负加速度为加速后退
			if (acc == 0)
				state = stopstate;
			else if (acc < 0)
				state = back;
			else
				state = ahead;
		} else {
			if (speed > 0) {
				if (acc == 0) {// 匀速行驶，不记录状态
					state = constant + ahead;
				}
				else if (acc < 0) {//减速前进
					state = decstate + ahead;
					if (isGPSon && laststate != state)
						as.sdec();
				} else {//加速前进
					state = constant + accstate;
					if (isGPSon && laststate != state)
						as.sacc();
				}
			} else {
				if (acc == 0) {
					state = constant + back;
				}// 匀速行驶，不记录状态
				else if (acc < 0) {//减速后退
					state = decstate + back;
					if (isGPSon && laststate != state)
						as.sdec();
				} else {//加速后退
					state = accstate + back;
					if (isGPSon && laststate != state)
						as.sacc();
				}
			}
		}
		lt = t;// 最后更新
		lastspeed = speed;
		laststate = state;
		Log.e("GPSspeed", state);

		return state;
	}
*/
	
	
	public String update(long t, float speed) {
		if(speed<0)return null;
		updaterecorder(t, speed, acc);// 先更新

		String state;
		float detaspeed = speed - lastspeed;
		long detat = t - lt;
		acc = (float) (1000 * (detaspeed * 3.6) / (detat));
		updatestatistic(speed, acc);

		state=adstate(speed,acc);
		if(state!=laststate&&state!=null)Log.e("gpsspeed",state);	
		
		lt = t;// 最后更新
		lastspeed = speed;
		laststate = state;
		if(state!=null)Log.e("GPSspeed", state);

		return state;
	}
	
	public String getstate() {

		return state;
	}

	// @时间@速度@加速度
	private void updaterecorder(long t, float s, float a) {
		float[] v = new float[] { s, a };
		Tuple<Long, float[]> tup = new Tuple<Long, float[]>(t, v);
		recorder.add(tup);
	}

	public float getacc() {
		return acc;
	}

	public float getmaxspeed() {
		return maxspeed;
	}

	public float getminspeed() {
		return minspeed;
	}

	public float getmaxacc() {
		return maxacc;
	}

	public float getaveragespeed() {
		return (float) (average / (count + 0.0001));
	}

	public float getslow() {
		return slowtimer;
	}

	// 用于最后调用的统计数据，在退出时进行触发
	public void updateinend() {
		as.setmaxspeed(maxspeed);
		as.setminspeed(minspeed);
		as.setavgspeed(getaveragespeed());
		as.setacc(maxacc);
		as.setslow(slowtimer / 3600);// 返回小时数
	}

	
	
	public String state(float speed,float acc){
		String state="";
		if(acc>0){state+="加速"; as.sacc();
		if(acc>15)as.aggacc();//急加速	
		}
		else {state+="减速"; as.sdec();
		if(acc<-15)as.aggdec();//急减速
		}
		if(speed>0)state+="前进";
		else if(speed==0)state+="静止";
		else state+="后退";//GPS速度不具备方向性，所以该情况不会出现
		return state;
		
	}
	
	//按实时速度和速差进行分类，0-30-60-90-   8-10-12-14
	public String adstate(float speed,float acc){
		if(acc==0&&speed>0){
			
			return "匀速前进";}
		if(acc==0&&speed<0){
			
			return "匀速倒车";}
		
		if(speed<30){
			if((acc*3.6)/speed>0.08)
			return state(speed,acc);
			else return null;
		}
		else if(speed<60){
			if((acc*3.6)/speed>0.1)
				return state(speed,acc);
				else return null;
		}else if(speed<90){
			if((acc*3.6)/speed>0.12)
				return state(speed,acc);
				else return null;
		}
		else {
			if((acc*3.6)/speed>0.14)
				return state(speed,acc);
				else return null;
		}
		
	}
}
