package com.speed;
//当前使用一个决策树来判断是否停车，
//采用一个滑动窗口，大小1s，正好与gps窗口相同
//决策值使用experiences with eNav所采用的四个维度加速度计的max min mean standard deviation
public class DecisionTree {

	float min=0,max=0,mean=0,sd=0;
	float offset=0;
	//用来修正手机不稳 非垂直轴的修正问题
	public void initoffset(float a){
		this.offset=a;
		
	}
	
	
	//获取加速度计的值
	public void update(){
		
		
	}
	
	
}
