package com.DTW;

import java.util.LinkedList;

public class DTWDistance {

//w 为阈值 x∈a , y∈b， |x-y|<=w时工作	
public float getDRWDistance(float[] a, float[] b, int w){
	
	float distance=0;
	int asize=a.length;
	int bsize=b.length;
	w=max(w,Math.abs(asize-bsize));
	
	float[][] DTW=new float[asize+1][bsize+1];
	
	for(int i=0;i<=asize;i++)
		for(int j=1;j<=bsize;j++)
		    DTW[i][j]=Integer.MAX_VALUE;
	DTW[0][0]=0;
	for(int i=1;i<=asize;i++)
		for(int j=max(1,i-w);j<=min(bsize,i+w);j++)
			{
			float cost=d(a[i-1],b[j-1]);
			DTW[i][j]=cost+min(DTW[i-1][j],DTW[i][j-1],DTW[i-1][j-1]);		
			}
			
			
	return distance;
}

public float getDRWDistance(float[] a, float[] b){
	
	float distance=0;
	int asize=a.length;
	int bsize=b.length;
	float[][] DTW=new float[asize+1][bsize+1];
	
	for(int i=1;i<=asize;i++)
		DTW[i][0]=Integer.MAX_VALUE;
	for(int i=1;i<=bsize;i++)
		DTW[0][i]=Integer.MAX_VALUE;
	DTW[0][0]=0;
	for(int i=1;i<=asize;i++)
		for(int j=1;j<=bsize;j++)
			{
			float cost=d(a[i-1],b[j-1]);
			DTW[i][j]=cost+min(DTW[i-1][j],DTW[i][j-1],DTW[i-1][j-1]);		
			}
			
			
	return distance;
}


public float d(float a,float b){
	return (float)Math.sqrt(a*a+b*b);	
}

public float min(float a,float b, float c){
	float min=Integer.MIN_VALUE;
	if (a<b)min=a;
	else min=b;
	if(min<c)return min;
	else return c;
}

public int min(int a,int b){
	if(a>b)return b;
	else return a;
}

public int max(int a,int b){
	if(a>b)return a;
	else return b;
	
}


}
