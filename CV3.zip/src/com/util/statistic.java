package com.util;

import android.util.Log;

import com.speed.GPSspeed;

public class statistic {

	private static int leftturn=0;
	private static int rightturn=0;
	private static int leftlane=0;
	private static int rightlane=0;
	private static int acc=0;
	private static int dec=0;
	private static int uturn=0;
	private static double totaldistance=0;
	private static double newtotaldistance=0;
	private static int use=0;//手机使用次数
	//GPSspeed myspeed=new GPSspeed();
	private static float maxspeed;
	private static float minspeed;
	private static float avgspeed;
	private static float maxacc;
	private static float slow;
	//关于危险统计变量
//	private static int alt=0;//aggressive-left-turn  危险左转    危险驾驶行为统计
//	private static int art=0;//aggressive-right-turn 危险右转
//	private static int aaac=0;//aggressive-acc 危险加速
//	private static int adec=0;//aggressive-dec 危险减速
//	private static int all=0;//aggressive-right-laning 危险左变道
//	private static int arl=0;//aggressive-right-laning 危险右变道
//	private static int aut=0;//aggressive-u-turn 危险掉头
//	private static int ac=0;//aggressive-carve 危险的曲线行驶
	
	private static int aggturn=0;//危险转向
	private static int agglane=0;//危险变道
	private static int agguturn=0;//危险掉头
	private static int aggcurve=0;//危险曲线行驶
	private static int aggacc=0;//危险加速
	private static int aggdec=0;//危险减速
	
	//统计gps失效率，失效使用定位码来确定
	private static int gpsavailable=0;
	private static int gpsloss=0;
	private static int satellitenumber=0;
	private static int count=0;
	
	//有数据点，
	public void updategpsa(){
		gpsavailable++;
	}
	//某个时间点没有gps
	public void updategpsl(){
		gpsloss++;
	}
	//统计gps卫星,当前时间片搜寻的卫星数量
	public void updatesatellite(int num){
		satellitenumber=satellitenumber+num;
		count++;
	}
	
	
	
	//输出,会在core使用结束后输出
	public String output(){
		
		
		String s="";
			s=s+"左转："+this.getslt()+"次\n"+
				"右转："+this.getsrt()+"次\n"+
				"左变道："+this.getsll()+"次\n"+
				"右变道："+this.getsrl()+"次\n"+
				"掉头："+this.uturn+"次\n"+
				"加速："+this.getsacc()+"次\n"+
				"减速："+this.getsdec()+"次\n"+
				"总里程："+this.gettotaldistance()/1000+"km\n"+
				"总里程（s级更新）："+this.getnewtotaldistance()/1000+"km\n"+
				"最大速度："+this.getmaxspeed()+"km/h\n"+
				"最小速度："+this.getminspeed()+"km/h\n"+
				"平均速度："+this.getavgspeed()+"km/h\n"+
				"最大加速度："+maxacc+"m/s^2\n"+
				"低速驾驶时长："+slow+"h\n"+
				"手机触控次数："+use+"次\n"+
				"危险行为：\n"+
				"危险加速："+aggacc+"次\n"+
				"危险减速："+aggdec+"次\n"+
				"危险转向："+aggturn+"次\n"+
			//	"危险右转："+art+"次\n"+
				"危险变道："+agglane+"次\n"+
			//	"危险右变道："+arl+"次\n"+
				"危险掉头："+agguturn+"次\n"+
				"危险曲线行驶："+aggcurve+"次\n"+
				"GPS失效率:"+(int)(gpsloss/(gpsavailable+0.001))+
				"平均搜星数量："+(int)(satellitenumber/(count+0.00001));
		return s;
	}
	
	public void init(){
		
		leftturn=0;
		rightturn=0;
		leftlane=0;
		rightlane=0;
		acc=0;
		dec=0;
		uturn=0;
		totaldistance=0;
		newtotaldistance=0;
		use=0;//手机使用次数
	}
	
	//初始化危险变量
	public void initav(){
		
/*	 alt=0;//aggressive-left-turn  危险左转    危险驾驶行为统计
	 art=0;//aggressive-right-turn 危险右转
	 aaac=0;//aggressive-acc 危险加速
	 adec=0;//aggressive-dec 危险减速
	 all=0;//aggressive-right-laning 危险左变道
	 arl=0;//aggressive-right-laning 危险右变道
	 aut=0;//aggressive-u-turn 危险掉头
	 ac=0;//aggressive-carve 危险的曲线行驶
	*/
		 aggturn=0;//危险转向
		agglane=0;//危险变道
		agguturn=0;//危险掉头
		aggcurve=0;//危险曲线行驶
	 	aggacc=0;//危险加速
		 aggdec=0;//危险减速
		
	}
	
	
	
	public void updatetotaldistance(double td){
		totaldistance+=td;
	}
	
	public double gettotaldistance(){
		return this.totaldistance;
	}
	
	public void updatenewtotaldistance(double td){
		newtotaldistance+=td;
	}
	
	public double getnewtotaldistance(){
		return this.newtotaldistance;
	}
	
	public void updateuse(){
		use++;	
	}
	
	public void setmaxspeed(float s){
		maxspeed=s;}
	
	public float getmaxspeed(){
		return maxspeed;
	}
	
	public void setminspeed(float s){
		minspeed=s;}
	
	public float getminspeed(){
		return minspeed;
	}
	
	public void setavgspeed(float s){
		avgspeed=s;}
	
	public float getavgspeed(){
		return avgspeed;
	}
	//缓慢行驶的时间
	public void setslow(float s){
		slow=s;}
	
	
	public void setacc(float s){
		maxacc=s;
	}
	
	
	//更新 左转
	public void slt(){
		leftturn++;
		Log.e("左转",leftturn+" "+System.currentTimeMillis());
	}
	//更新 右转
	public void srt(){
		rightturn++;
		Log.e("右转",rightturn+" "+System.currentTimeMillis());
	}
	
	
	//更新 左变道
	public void srl(){
		rightlane++;
		Log.e("右变道",rightlane+" "+System.currentTimeMillis());
	}
	
	//更新 右变道
	public void sll(){
		leftlane++;
		Log.e("左变道",leftlane+" "+System.currentTimeMillis());
	}
	
	public void sacc(){
		acc++;
	}
	public void sdec(){
		dec++;
	}
	
	public void sut(){
		uturn++;
		Log.e("掉头",uturn+" "+System.currentTimeMillis());
	}
	
	
	//获取单个，用于实时输出的接口
	public int getslt(){
		return leftturn;
	}
	
	public int getsrt(){
		return rightturn;
	}
	
	public int getsrl(){
		return rightlane;
	}
	public int getsll(){
		return leftlane;
	}
	public int getsacc(){
		return acc;
	}
	
	public int getsdec(){
		return dec;
	}
	
	
	public void stt(){
	//调用线性回归	
	}
	
	
	//危险驾驶行驶变量更新
	public void aggturn(){
		aggturn++;
	}
	
	public void aggacc(){// GPSspeed-line 208
		aggacc++;
	}
	public void aggdec(){//GPSspeed-line 211 加速度>15 
		aggdec++;
	}
	public void agglane(){
		agglane++;
	}
	
	public void agguturn(){
		agguturn++;
	}
	public void aggcurve(){
		aggcurve++;
	}
	
}
