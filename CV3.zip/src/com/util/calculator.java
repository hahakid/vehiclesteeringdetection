package com.util;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.commons.math3.util.FastMath;

import java.util.Collections;

import android.util.Log;

//用于计算统计参数的 统计计算器
//3/1/16增加了求和，并去除了排序操作，直接使用未排序数值（主要影响 中位数和 上/下四分位数）
public class calculator {
	double min = 10000;
	double max = 0;
	double mean = 0;
	double sd = 0;// standard deviation
	double var = 0;// variance
	double entropy = 0;
	double energy = 0;// 暂未查阅到相关计算公式
	double median = 0;// 中值
	double quartiles_up = 0, quartiles_down = 0;// 上下四分位数
	double RMS = 0;// 均方根
	double sum=0;
	DecimalFormat df = new DecimalFormat("######0.000");// 保留两位小数用
	HashMap<Float, Integer> info = new HashMap<Float, Integer>();

	
	public void init(){
		min=10000;
		max=0;
		mean=0;
		sd=0;
		var=0;
		entropy=0;
		energy=0;
		median=0;
		quartiles_up=0;
		quartiles_down=0;
		RMS=0;
		sum=0;
		info = new HashMap<Float, Integer>();
	}
	
	public void calculate(ArrayList<Float> l) {
		// 排序,不能排序
		//Collections.sort(l);

		int i = 0;
		int length = l.size();
		float mean2 = 0;
		// 求 中值和四分位数
		if (length % 2 != 0) {// 奇
			median = l.get((length - 1) / 2);// 1/2
			quartiles_up = l.get((int) ((length - 1) / 4));// 1/4
			quartiles_down = l.get((int) ((length - 1)*3/4));// 3/4
		} else {// 偶
			median = l.get(length / 2);
			quartiles_up = l.get((int) (length / 4));
			quartiles_down = l.get((int) (length*3/4));
		}

		// 第一次循环，求最值和均值
		while (i < length) {
			float cur = l.get(i);
			if (min > cur)
				min = cur;
			if (max < cur)
				max = cur;
			sum += l.get(i);//求和
			mean2 += FastMath.pow(l.get(i), 2);
			
			if (info.containsKey(cur)) {
				int n = info.get(cur) + 1;
				info.put(cur, n);
			} else
				info.put(cur, 1);

			RMS += FastMath.pow(l.get(i), 2);

			i++;
		}
		
		RMS = FastMath.sqrt(RMS / length);
		mean =sum/length;//求均值
		mean2 /= length;
		var = (float) (mean2 - FastMath.pow(mean, 2));
		// 第二次循环， 求方差 标准差 熵
		i = 0;
		while (i < length) {
			sd += FastMath.pow(l.get(i) - mean, 2); // （x-x'）^2

			i++;
		}
		sd /= length;
		sd = (float) FastMath.sqrt(sd);

		for (Entry<Float, Integer> entry : info.entrySet()) {

			double p = entry.getValue() / (double) length;
			entropy += p * log(p);
		}

	}

	
	public String getinfo() {
		return info.toString();
	}

	// 可能不兼容apache的
	public double log(double a) {
		return (FastMath.log(2, a));
	}

	public double getmin() {
		return this.min;
	}

	public double getmax() {
		return this.max;
	}

	public double getsd() {
		return this.sd;
	}

	public double getvar() {
		return this.var;
	}

	public double getentropy() {
		return this.entropy;
	}

	public double getenergy() {
		return this.energy;
	}

	public double getRMS() {
		return this.RMS;
	}

	public double getmedian() {
		return this.median;
	}

	public double getquartiles_up() {
		return this.quartiles_up;
	}

	public double getquartiles() {
		return this.quartiles_down;
	}

	public double getsum() {
		return this.sum;
	}
	
	public String getallinfo(){
		String s=df.format(min)+" "+df.format(max)+" "+df.format(sd)+" "+
	df.format(var)+" "+df.format(entropy)+" "+df.format(RMS)+" "+
				df.format(quartiles_up)+" "+df.format(quartiles_down);
		return s;
	}
}
