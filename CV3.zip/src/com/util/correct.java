package com.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import android.util.Log;

public class correct {

	
	private HashMap<Float,Integer> mm=new HashMap<Float,Integer>();;
	
	//使用一个hashmap来存储出现的传感器数值与出现频率的关系
	public void update(ArrayList<Float> dz) {
		mm=new HashMap<Float,Integer>();//顺带着初始化
		int s=dz.size(),i=0;
		while(i<s){
			float key=dz.get(i);
			if(mm.containsKey(key)){
			int value=mm.get(key)+1;	
			mm.put(key, value);
			}
			else {//没有的时候
				mm.put(key, 1);
			}
			i++;
		}
	}
	
	public float getoffset(String s){
		float offset=0f;
		int max1=0,max2=0,max3=0;//用来存放频率最高的两个的频数
		float max11=0,max22=0,max33=0;//用来存放频率最高的两个值
		for(Entry<Float,Integer> entry:mm.entrySet()){
			if(max1<entry.getValue())
			{		max3=max2;
					max2=max1;
					max1=entry.getValue();
					max33=max22;
					max22=max11;
					max11=entry.getKey();
			}
			
		}
		
	//	Log.e("new:"+s,max1+" "+max11+" "+max2+" "+max22+" "+max3+" "+max33);
		
		
		if(max11==0&&max22==0&&max33==0) offset=0;//排名前2的都是0 不修正
		if(max11==0&&max33==0) offset=-max22;// 直接修正非零
		if(max22==0&&max33==0) offset=-max11;
		if(max11==0&&max22==0) offset=-max33;
		if(max11==0) offset=(max2*max22+max3*max33)/(max2+max3);
		if(max22==0) offset=(max1*max11+max3*max33)/(max1+max3);
		if(max33==0) offset=(max2*max22+max1*max11)/(max1+max2);	
		if(max11!=0&&max22!=0&&max33!=0)offset=(max2*max22+max1*max11+max3*max33)/(max1+max2+max3);	
		return offset;
	}
	
}
