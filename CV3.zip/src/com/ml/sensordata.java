package com.ml;

import java.util.ArrayList;
//数据存储
//获取单个multiwave事件范围内所有的传感器数值链表 进行存储






import com.turn.wave;

import android.util.Log;
//这个类在multiwave处理的过程中被调用，实时的去捕获相应的数值

public class sensordata {
//时间相关的参数暂时不管了
	private int length = 0;// 事件持续时间
	private long tbt=0,tet=0;//总起始时间
	private long bt=0,et=0;//当前波起始时间
	
	//6个传感器数值
	private ArrayList<ArrayList<float[]>> wavesensor = new ArrayList<ArrayList<float[]>>();//存放传感器数值
	private ArrayList<ArrayList<Float>> wavespeed=new ArrayList<ArrayList<Float>>();//存放速度值
	//private ArrayList<Float> ay = new ArrayList<Float>();
	//private ArrayList<Float> az = new ArrayList<Float>();
	//private ArrayList<Float> dx = new ArrayList<Float>();
	//private ArrayList<Float> dy = new ArrayList<Float>();
	//private ArrayList<Float> dz = new ArrayList<Float>();
	//private ArrayList<Float> speed = new ArrayList<Float>();
	
	//添加滤波操作
	//重新装载新波的时候需要初始化
	public void initlist(){
		wavesensor.clear();
		wavespeed.clear();
	}
	//清空总时长
	public void clearlength(){
		length=0;
	}
	//记录开始时间
	public void gettbt(long b){
		this.tbt=b;
	}
	
	//记录结束时间
	public void gettet(long e){
		this.tet=e;
	}
	//获取时长
	public void getdur(){
		
	}
	
	
	//更新值,从Multiwave获取
	public void updatelist(ArrayList<float[]> currentwaves,ArrayList<Float> currentspeed){
		wavesensor.add(currentwaves);
		wavespeed.add(currentspeed);
	}
	
	//将当前波信息输出
	public void output(){
		int l1=wavesensor.size();
		int l2=wavespeed.size();
		String s=null;
		if(wavesensor.isEmpty())s="null\n";
		else{
			for(int i=0;i<wavesensor.size();i++){
				s+="NO."+i+"个:\n\n";
				for(int j=0;j<wavesensor.get(i).size();j++){
					for(int k=0;k<wavesensor.get(i).get(j).length;k++){
						s+=wavesensor.get(i).get(j)[k]+" ";
					}
					s+="\n";
				}	
			}
		}
		Log.e("sensordata----",s+" ");
		}
	
	
}
