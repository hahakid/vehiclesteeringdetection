package com.turn;

import java.util.ArrayList;

import vehicle.car;
import android.util.Log;

import com.ml.sensordata;
import com.util.calculator;
import com.util.statistic;

public class multiwave {
	// 多波存储链表，存放一次事件中的连续多个波，条件为低于delay出现的连续波
	private ArrayList<waveinfo> mwave=new ArrayList<waveinfo>();
	
	//只记录每个传感器数值，测试后改称用sensordata记录各项指标，然后计算统计量
	private ArrayList<ArrayList<float[]>> sdlist=new ArrayList<ArrayList<float[]>>();
	private ArrayList<ArrayList<Float>> speedlist=new ArrayList<ArrayList<Float>>();
	//用于记录每个multiwave波形内的传感器及各轴数据2×3=6（目前）
	sensordata sd=new sensordata();//sensordata
	// 新的类状态 空闲等待--出现潜在波--记录波--
	/*
	 * 1.初始为silence空状态，监听dz>0.05判断是否进入check 
	 * 2.check：dz>0.05&&持续时间>状态 
	 * 3.记录状态
	 * 4.下一波检测状态 
	 * 5.当前状态，回到1
	 */
	final static int silence = 1; // 没有
	final static int check = 2;// 单波待检测
	final static int record = 3;// 单波出现
	final static int next = 4;// 双波待检测
	//初始为1 静默监听状态
	private int state = silence;
	// 基本检波信息阈值 1-基本 2-变道 3-转向及其他
	final float basedz1 = (float) 0.04;//略小
	final float basedz2 = (float) 0.07;
	final float basedz3 = (float) 0.11;
	
	final int baset = 1500;// 单个波持续的最小时长
	final int delay = 2000;// 两波生成相邻最大间隔

	long last = 0;// 当前状态的上一个时间点 ,只在需要的时候更新
	//long lasttest=0;
	long lastw = 0;// 上一个波结束的时间
	// multi标志位，控制check状态向silence状态跳转；还是向next跳转（在间隔小于delay情况）
	boolean mflag = false;// false 表示第一个波的检测，true表示检测多个波
	wave currentwave = new wave();// 存放当前检测到的波信息
	
	//sensordata sd=new sensordata();//存放所有传感器数值
	
	// 波相关信息维持的状态量,输入进波
	long bt;
	long et;
	// float min;
	float max;
	//状态
	final int other=0;
	final int left=1;
	final int right=2;
	final int turn=3;
	final int lane=4;
	final int uturn=5;
	final int curve=6;
	String[] result={"other","left","right","turn","lane","uturn","curve"}; 
	
	//String[] result1={"other","leftturn","rightturn","leftlane","rightlane","leftuturn","rightuturn"}; 
	
	//暂存所有传感器数值 sensor-list-info
	ArrayList<String> sli=new ArrayList<String>();
	//暂存对应的速度信息 speed-info
	ArrayList<String> si=new ArrayList<String>();
	//存放统计计算之后的数值
	ArrayList<String> csli=new ArrayList<String>();
	
	ArrayList<String> csi=new ArrayList<String>();
	
	String fresult=null;//最后结果
	
	//统计信息
	statistic ts=new statistic();
	int lr=0;//左=true 右=false
	int mode=0;//0=other，3=turn，4=lane，5=uturn
	
	car mycar=new car();//汽车类分级评分
	//private static ArrayList<Tuple<String,Integer>> score=new ArrayList<Tuple<String,Integer>>();//分数列表<类型，分数>
	
	public void initinfo() {
		bt = 0;
		et = 0;
		max = 0;
		// min=10;
		last = 0;
	}
	// @当前时间片@角速度传感器z轴值@当前速度@所有传感器数值数组
	public void checkstate(long time, float dz, float s, float[] as) {
		
		switch (state) {

		case (silence):
			{silence(time, dz, s,as);//Log.e("checkstate","silence");
			}
			break;
		case (check):
			{check(time, dz, s, as);//Log.e("checkstate","check");
			}
			break;
		case (record):
			{record(time, dz,s,as);//Log.e("checkstate","record");
			}
			break;
		case (next):
			{next(time, dz, s,as);//Log.e("checkstate","next");
			}
			break;
		}
	}

	// 检测是否存在下一个波
	private void next(long time, float dz, float speed,float[] as) {
		if (time - lastw <= delay) {// breach-A 自跳转// 时间未到，继续轮询
			if (Math.abs(dz) >= basedz1) {// breach-B 跳转到check，这个时候 mflag=true
				
				changestate(check);
				{
					currentwave.updatewave(dz);// 对当前波的第一次设定
					currentwave.setwb(time);// 并记录开始时间wb时间
					currentwave.updatespeed(speed);
					currentwave.updateas(as);//实时更新当前波all
				}
		}			
			
		} else {// breach-C 跳转到silence，在这之前 对multiwave进行分析
				// multiwave分析模块{变道，转向，掉头，其他}
			
			fresult=analysis();
			Log.e("multiwave-analysis", fresult);
			
			//op_mw_sensor();
			sli=allsensor2string();//raw sensor
			si=allspeed2string();//raw speed
			csli=statinfo2string();//stat sensor
			csi=statspeed2string();//stat speed
			//sd.output();
			
			updatestatistic(lr,mode);
			mwave.clear();
			sdlist.clear();
			sd.initlist();
			speedlist.clear();
			mflag = false;
			changestate(silence);
		}
	}
	
	//测试波形内传感器数值输出
	public void op_mw_sensor(){
		//int l=mwave.size();
		if(!mwave.isEmpty()){
		for(int i=0;i<mwave.size();i++){
		Log.e("In-multiWave","the "+i+" wave\n");
		mwave.get(i).showsensorinfo();	
		}
		}
	}
	
	//将传感器信息转换为字符串链表
	public ArrayList<String> allsensor2string(){
	//public void allsensor2string(){
		ArrayList<String> sl=new ArrayList<String>();
		if(!mwave.isEmpty()){
			for(int i=0;i<mwave.size();i++){//逐个添加每个波形的数据
			sl.add("the "+i+" wave");//波序号
			sl.add(mwave.get(i).getwb()+"--"+mwave.get(i).getwe());//波开始--结束时间
			sl.addAll(mwave.get(i).sensorinfo2list());//传感器内容	
			}
			}
		
		for(int i=0;i<sl.size();i++){
			Log.e("In-multiwave-a2s",sl.get(i));
		}
		return sl;
		//else return null;
	}
	
	//将传感器信息转换为字符串链表
		public ArrayList<String> allspeed2string(){
		//public void allsensor2string(){
			ArrayList<String> sl=new ArrayList<String>();
			if(!mwave.isEmpty()){
				for(int i=0;i<mwave.size();i++){//逐个添加每个波形的数据
				sl.add("the "+i+" wave");//波序号
				sl.add(mwave.get(i).getwb()+"--"+mwave.get(i).getwe());//波开始--结束时间
				sl.addAll(mwave.get(i).speedinfo2list());//速度内容
				}
				}
			
		//	for(int i=0;i<sl.size();i++){
		//		Log.e("In-multiwave-a2s",sl.get(i));
		//	}
			return sl;
			//else return null;
		}
	
		//传感器统计值计算转换到string
		public ArrayList<String> statinfo2string(){
			ArrayList<String> sl=new ArrayList<String>();
			if(!mwave.isEmpty()){
				for(int i=0;i<mwave.size();i++){//逐个添加每个波形的数据
					//Log.e("cangetsensor????",precal(mwave.get(i).getallsensors()));
					sl.add("No."+i+":");
					sl.addAll(precal(mwave.get(i).getallsensors()));//调用统计计算器，计算每个波的统计值
				}
				}
			return sl;
		}
		
		//传感器统计值计算转换到string
				public ArrayList<String> statspeed2string(){
					ArrayList<String> sl=new ArrayList<String>();
					if(!mwave.isEmpty()){
						for(int i=0;i<mwave.size();i++){//逐个添加每个波形的数据
							sl.add("No."+i+":");
							calculator cc=new calculator();
							cc.calculate(mwave.get(i).getspeedl());
							sl.add(cc.getallinfo());//调用统计计算器，计算每个波的speed统计值
						}
						}
					return sl;
				}
		
	//清空sli和sl，在core调用,各变量分开调用主要是因为：1）室内测试没有gps信号，2）在外面部分区域GPS可能出现失效的空白区域
	public void initsli(){//raw sensor
		sli=new ArrayList<String>();	
	}
	
	public void initsi(){//raw speed
		si=new ArrayList<String>();
	}
	
	public void initcsli(){//statistic sensor
		csli=new ArrayList<String>();	
	}
	
	public void initcsi(){//statistic speed
		csi=new ArrayList<String>();
	}
	
	//获取sli 在core调用
	public ArrayList<String> getsli(){
		return sli;
	}
	//获取si 在core调用
	public ArrayList<String> getsi(){
		return si;
	}
	//获取csli
	public ArrayList<String> getcsli(){
		return csli;
	}
	
	public ArrayList<String> getcsi(){
		return csi;
	}
	
	//因为传感器数据存储为ArrayList<float[]>,需要将每个float[6]分别提取到ArrayList<float>,然后调用calculator计算统计数值
	public ArrayList<String> precal(ArrayList<float[]> sl){
		ArrayList<String> s=new ArrayList<String>();
		
		ArrayList<Float> ax=new ArrayList<Float>();
		ArrayList<Float> ay=new ArrayList<Float>();
		ArrayList<Float> az=new ArrayList<Float>();
		ArrayList<Float> dx=new ArrayList<Float>();
		ArrayList<Float> dy=new ArrayList<Float>();
		ArrayList<Float> dz=new ArrayList<Float>();
		for(int i=0;i<sl.size();i++){
			ax.add(sl.get(i)[0]);
			ay.add(sl.get(i)[1]);
			az.add(sl.get(i)[2]);
			dx.add(sl.get(i)[3]);
			dy.add(sl.get(i)[4]);
			dz.add(sl.get(i)[5]);
		}
		calculator cc=new calculator();
		cc.calculate(ax);
		s.add("ax "+cc.getallinfo());
		cc.init();
		cc.calculate(ay);
		s.add("ay "+cc.getallinfo());
		cc.init();
		cc.calculate(az);
		s.add("az "+cc.getallinfo());
		cc.init();
		cc.calculate(dx);
		s.add("dx "+cc.getallinfo());
		cc.init();
		cc.calculate(dy);
		s.add("dy "+cc.getallinfo());
		cc.init();
		cc.calculate(dz);
		s.add("dz "+cc.getallinfo());
		cc.init();
		//Log.e("In-multiwave",s);
		return s;
	}
	
	
	//获取每个波的数值
	public String sdlistinfo(){
		String s=null;
		if(sdlist.isEmpty())s="null";
		else{
			for(int i=0;i<sdlist.size();i++){
				s+=i+" :\n\n";
				for(int j=0;j<sdlist.get(i).size();j++){
					for(int k=0;k<sdlist.get(i).get(j).length;k++){
						s+=sdlist.get(i).get(j)[k]+" ";
					}
					s+="\n";
				}	
			}
		}
		return s;
	}
	
	public String getresult(){
		return fresult;
	}
	
	public void initresult(){
		fresult=null;
	}
	
	// 将当前波状态复制存入multiwave链表中，并清空当前链表内容
	private void record(long time, double dz,float s,float[] as) {// 单向，转向next
		long cwb=currentwave.getwb();	
		long cwe=currentwave.getwe();	
		float cmax=	currentwave.getdmax();
		float cavg=currentwave.getavg();
		float cspeed=currentwave.getspeed().get(0);//之前的逻辑是用第一个时间点的速度
		
		ArrayList<float[]> callsensor=currentwave.getallsensors();//获取全部传感器数值
		ArrayList<Float> cspeedl=currentwave.getspeed();//获取全部速度
		waveinfo cwave=new waveinfo(cwb,cwe,cmax,cavg,cspeed,callsensor,cspeedl);
		mwave.add(cwave);
		sdlist.add(currentwave.getallsensors());//全传感器
		speedlist.add(currentwave.getspeed());//速度
		sd.updatelist(currentwave.getallsensors(), currentwave.getspeed());
		changestate(next);
		mflag = true;// 开启多波
	}

	// 检测是否形成了一个波 @当前时间片@角速度传感器z轴值@当前速度@所有传感器数值数组
	private void check(long time, float dz, float speed,float[] as) {
		if (mflag == false) {//目前只有一个波的情况
			if (Math.abs(dz) >= basedz1) {// 当前波依然在持续 breach-A 自跳转
				//1检波更新操作
				last = time;
				currentwave.updatewave(dz);// 会实时更新当前波，的角速度传感器z轴
				currentwave.updateas(as);//更新所有传感器数值
			}// 只用更新
			else {// 当前波结束，进入记录状态
				if (isabump(time)) {// 构成一个基本波 breach-B 跳转到record
					changestate(record);// 检测出一个波，对波进行存储
					{
						currentwave.setwe(last);// 并设定最后时间
					}
					lastw = last;// 本次波结束，开始记录lastw的时间点
				} else {// 未达到基本波条件 breach-C 跳转到silence
					initinfo();
					changestate(silence);
				}
			}
		} else {//检测多于一个波的情况， 在与next之间的切换，间隔<delay的情况 breach-D 跳转到next
			if (Math.abs(dz) > basedz1) {// 记录currentwave breach-A 自跳转
				last = time;
				currentwave.updatewave(dz);// 实时更新当前波dz
				currentwave.updateas(as);//实时更新当前波all
			} else if (isabump(time)) {// 形成波
				changestate(record);// 检测出一个波，对波进行存储
				{
					currentwave.setwe(last);// 并设定最后时间
					//2该如何处理？？？？
				}
				lastw = last;// 本次波结束，开始记录lastw的时间点
				last = time;//0
			} else {// 只要未形成波，就跳转回next，通过next判断超时，跳转到silence
				currentwave.init();
				initinfo();
				changestate(next);
			}
		}
	}

	private boolean isabump(long time) {
		// TODO Auto-generated method stub
		return ((time - currentwave.getwb() > baset) && (Math.abs(currentwave
				.getdmax()) >= basedz2));
	}

	public void changestate(int s) {
		state = s;
	}

	// 没有波的状态， 根据dz是否大于basedz1 改变状态，
	//是 进入check状态，继续检测当前数值是否构成一个波形
	//否 进入下一次轮询
	public void silence(long t, float dz, float speed,float[] as) {
		currentwave.init();// 什么都没有当前波会被清空所有状态
		//初始清空
		if (Math.abs(dz) >= basedz1) {// breach-B 跳转向check
			initinfo();
			changestate(check);// 触发dz>basedz 进入检测状态
			{	//波形检测操作
				currentwave.setwb(t);// 并记录开始时间wb时间
				currentwave.updatewave(dz);// 对当前波的第一次设定				
				currentwave.updatespeed(speed);
				currentwave.updateas(as);//测试存放传感器数值
				
			}
		}	// breach-A 自我跳转
	}
	
	public String analysis1() {
		if (mwave != null) {
			String s = "list:" + mwave.size() + ":";
			for (int i = 0; i < mwave.size(); i++) {
				waveinfo w = mwave.get(i);
				s += "\n" + i;
				s += "\nbegin:" + w.getwb();
				s += "\nend:" + w.getwe();
				s += "\nduration:" + w.getdur();
				s += "\nmax:" + w.getmax();								
				s += "\navg:" + w.getavg();
				s+="\nspeed:"+w.getspeed();
				s += "\nP-N:"+w.getPN();
			}
			return s;
		} else
			return "nothing";// 不会出现，一定有第一个波成立，才回跳转到next状态
	}
	
	
	//1.单播：转向/掉头，先判断总角度，再判断左右
	//2.双波：转向/掉头/变道 先判断总角度，再判断左右
	//3.三波：转向/掉头，先判断总角度，在判断左右
	//4.>=4：非直线驾驶，频繁变道，无法掌控车辆保持平稳，非正常驾驶等情况，>8 酒驾？？？
	public String analysis() {
		if (mwave != null) {
			int total=mwave.size();
			switch(total){
			case 1:return onewave(total);//单波
			case 2:return twowave(total);//双波
			case 3:return threewave(total);//三波
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:mycar.other(total);return "cannot keep driving straight！";// 无法正常掌控车辆直行
			default: return "drink driving！";//酒驾	还没考虑是否进行负分		
			}
		
			
			
		} else
			return "nothing";// 不会出现，一定有第一个波成立，才回跳转到next状态
	}
	
	//处理统计信息，只有掉头没分左右，但原鲜果的，变道也没分左右
	public void updatestatistic(int a,int b){
	//	Log.e("wavestatic",ts.output());
		if(a==1){//左
			//ts.slt();
			switch(b){
			case 3:ts.slt();break;
			case 4:ts.sll();break;
			case 5:ts.sut();break;
			}
		}
		else if(a==2){//右
			//ts.srt();
			switch(b){
			case 3:ts.srt();break;
			case 4:ts.srl();break;
			case 5:ts.sut();break;
			}
		}
	}
	
	
	
	//单个波 正负+角度
	public String onewave(int total){
		String s="";
		
		float avg=mwave.get(total-1).getavg();
		float dur=mwave.get(total-1).getdur();
		float max=mwave.get(total-1).getmax();
		float speed=mwave.get(total-1).getspeed();
		float degree=(float) (avg*dur*180/Math.PI/1000);
		float or=Math.abs(degree);
		if(avg>0){lr=1;state=left;}
		else {lr=2;state=right;}
		s=result[state];//得到左右
		s+=" "+tluc(1,or)+" 1";//2
		
		
		
		//评分 
		return s;
	}
	
	//turn OR lane OR u-turn OR curve
	public String tluc(int mode,float d){
	//	Log.e("tlu-exe","");
		switch(mode){
		case 1:return mode1(d);
		case 2:return mode2(d);
		}
		return "not considered";
		/*
		if(d>70&&d<90)return result[turn];
		if(d>160&&d<200)return result[uturn];
		if(d<20)return result[lane];
		return " "+result[turn]+" "+d+" 度";
		*/
	}
	//适用于 3 个波 和2波的 一正一负
	public String mode1(float d){
		if(d<30){mode=4;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[lane]+" "+d+" 度";}//空档只有[30:60]
		if(d>60&&d<=120){mode=3;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[turn]+" "+d+" 度";}
		if(d>120&&d<=150){mode=6;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[curve]+" "+d+" 度";}//turn<curve1< uturn 
		if(d>150&&d<=220){mode=5;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[uturn]+" "+d+" 度";}
		if(d>220){mode=6;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[curve]+" "+d+" 度";}//curve2> uturn
		
		//mycar.state(mode,mwave.get(0).getspeed(),mwave);//返回分数
		//Log.e("multiwave-1",mode+" "+mwave.get(0).getspeed());
		return " "+d+" 度";
	}
	
	//将当前状态获得分数作为输入，判断动作是否危险
	public void isaggressive(int m){
		//float score=mycar.state(m,mwave.get(0).getspeed(),mwave);//返回分数
		//switch(m){}
	}
	
	//2波的 正正 /负负 和  单波
	public String mode2(float d){
		if(d>60&&d<=120){mode=3;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[turn]+" "+d+" 度";}
		if(d>120&&d<=150){mode=6;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[curve]+" "+d+" 度";}//turn<curve1< uturn 
		if(d>150&&d<=220){mode=5;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[uturn]+" "+d+" 度";}
		if(d>220){mode=6;mycar.state(mode,mwave.get(0).getspeed(),mwave);return result[curve]+" "+d+" 度";}//curve2> uturn
		//mycar.state(mode,mwave.get(0).getspeed(),mwave);//返回分数
		//Log.e("multiwave-2",mode+" "+mwave.get(0).getspeed());
		return " "+d+" 度";
	}
	
	
	
	//两个波，通过 波的正负+角度判断
	public String twowave(int total){
		String s="";
		boolean[] pn=new boolean[total];
		float[] avg=new float[total];
		long[] dur=new long[total];
		float[] max=new float[total];
		float[] speed=new float[total];
		float degree=0;
		for(int i=0;i<total;i++){
			pn[i]=mwave.get(i).getPN();
			avg[i]=mwave.get(i).getavg();
			max[i]=mwave.get(i).getmax();
			dur[i]=mwave.get(i).getdur();
			speed[i]=mwave.get(i).getspeed();
			degree+=avg[i]*dur[i];
		}
		degree=(float)(degree*180/Math.PI/1000);
		float or=Math.abs(degree);
		
		//s+=tlu(or);
		
		
		if (avg[0]>0) {
			lr=1;
			s+=result[left];
			if (avg[1]>0) {// 正正= 左转/左掉头/左其它
				s+=" "+tluc(1,or)+" 2";	//2	
			} else {// 正负=左变道
				s+=" "+tluc(1,or)+" 2";
				
			}
		} else {
			lr=2;
			s+=result[right];
			if (avg[1]>0) {// 负正=右变道
				s+=" "+tluc(1,or)+" 2";
			} else {// 负负=右转/右掉头/右其它
				s+=" "+tluc(1,or)+" 2";//2
			}
		}
		return s;	
	}
	
	
	//三个波，太复杂直接用变化的角度判断
	public String threewave(int total){
		
		String s="";
		boolean[] pn=new boolean[total];
		float[] avg=new float[total];
		long[] dur=new long[total];
		float[] max=new float[total];
		float[] speed=new float[total];
		float degree=0;
		for(int i=0;i<total;i++){
			pn[i]=mwave.get(i).getPN();
			avg[i]=mwave.get(i).getavg();
			max[i]=mwave.get(i).getmax();
			dur[i]=mwave.get(i).getdur();
			speed[i]=mwave.get(i).getspeed();
			degree+=avg[i]*dur[i];
		}
		degree=(float)(degree*180/Math.PI/1000);
		float or=Math.abs(degree);
		if(degree>0){s+=result[left];lr=1;}
		else {s+=result[right];lr=2;}
		s+=" "+tluc(1,or)+" 3";
		return s;
	}
	
	//触发调度car进行运算
	public String getscores(){
		return mycar.calscore();
	}
	
}
