package com.turn;

//更改检波阈值为2个不同的大小，分别用于检测变道和转向，因为变道小，而转向大，底层的检测波发生的min阈值不变
//tbump： thresholds bumps
//来自专车的测试数据表明，三星s3手机能够采集检测出所有的转向，但是把变道误捡为转向，
//经过分析，我怕们选择若干统计数据进行指导设置，后期可以加大测试量，进行继续调整
//变道max=[0.08:0.25]
//转向max=[0.2,0.5]
//而原先的以0.07作为检测标准误差较大，而且专车司机（私家车，非出租）驾驶习惯比较良好。
import java.util.ArrayList;

import com.util.Tuple;
import com.util.statistic;

import android.util.Log;

//目前的波只检测连续2个波，但实际中可能有连续多个波，后续考虑加入随机不限制的波的检测
public class tbump {
	// 几种状态
	final static int no = 1; // 没有
	final static int oc = 2;// 单波待检测
	final static int one = 3;// 单波出现
	final static int tc = 4;// 双波待检测
	final static int two = 5;// 双波出现

	final static String lt = "左转";
	final static String rt = "右转";
	final static String ll = "左变道";
	final static String rl = "右变道";
	final static String ut = "掉头";

	private double s = 0.05;// 最小转角 可修改 0.08 数据来源 为论文VSense_MobiSys2015
	private double ht = 0.15;// 最大转角 h for turning=0.15
	private double hl = 0.09;// 最大转角 h for laning=0.07

	private int dwell = 1500;// 单个波持续时间
	private int next_delay = 2500;// ms 连续两个波的间隔时间 论文3s
	private int state = no;// no=没有。one=一个波，two=两个波
	private double maxZ1 = 0;// 第一个波的max_value
	private double maxZ2 = 0;// 第二个波的max_value
	long ostartt = 0;// 1起始时间
	long ofinisht = 0;// 1起始时间
	long tstartt = 0;// 2起始时间
	long tfinisht = 0;// 2起始时间
	long last = 0;

	long duration1=0;//存放第一个波持续时间
	long duration2=0;//存放第二个波持续时间
	
	float beginor = 0, endor = 0;// 开始角度--结束角度

	// 方向信息
	int all = 1000;
	ArrayList<Tuple<Long, Float>> or = new ArrayList<Tuple<Long, Float>>();

	// acc传感器x，y轴的数据
	// 用来计算相对位移的acc传感器数据 @时间 ax ay
	ArrayList<Tuple<Long, float[]>> accinfo = new ArrayList<Tuple<Long, float[]>>();
	// 用来计算相对位移的gps数据 @时间 x,y
	ArrayList<Tuple<Long, double[]>> gpsinfo = new ArrayList<Tuple<Long, double[]>>();
	// 记录方向.
	ArrayList<Tuple<Long, Float>> orientinfo = new ArrayList<Tuple<Long, Float>>();
	private String result = null;// 存入log的结果

	//private int slt=0,srt=0,sll=0,srl=0,sut=0;//统计个情况发生次数
	
	//statistic ts=new statistic();//动态更新statistic中的静态统计变量
	
	/*
	 * 单波 & maxZ1>0 左转 ； 单波& maxZ1<0 右转； 双波& maxZ1>0&max
	 */

	// long finisht=0;

	public void changestate(int s) {
		state = s;
	}

	public int getstate() {
		return state;
	}

	// 单波开始
	public void recordostart(long time) {
		ostartt = time;
	}

	// 单波结束
	public void recordofinish(long time) {
		ofinisht = time;
	}

	// 双波开始
	public void recordtstart(long time) {
		tstartt = time;
	}

	// 双波结束
	public void recordtfinish(long time) {
		tfinisht = time;
	}

	// 单波开始
	public long getostart() {
		return ostartt;
	}

	// 单波结束
	public long getofinish() {
		return ofinisht;
	}

	// 双波开始
	public long gettstart() {
		return tstartt;
	}

	// 双波结束
	public long gettfinish() {
		return tfinisht;
	}

	// no->one每次更新maxZ1
	public void updatemaxZ1(double dz) {
		// if (maxZ1 < Math.abs(dz))
		// maxZ1 = Math.abs(dz);
		if (dz > 0 && dz > maxZ1)
			maxZ1 = dz;
		else if (dz < 0 && dz < maxZ1)
			maxZ1 = dz;
	}

	// one-twocheck,每次更新maxZ2
	public void updatemaxZ2(double dz) {
		// if (maxZ2 < Math.abs(dz))
		// maxZ2 = Math.abs(dz);
		if (dz > 0 && dz > maxZ2)
			maxZ2 = dz;
		else if (dz < 0 && dz < maxZ2)
			maxZ2 = dz;
	}

	// 第一个波 初步过滤都用hl，如果最终满足条件直接就是变道
	public boolean isabump(long t) {
		return ((t - ostartt > dwell) && (Math.abs(maxZ1) >= hl));
	}

	// 第二个波 初步过滤都用hl，如果最终满足条件直接就是变道
	public boolean istbump(long t) {
		return ((t - tstartt >= dwell) && (Math.abs(maxZ2) >= hl));
	}

	public void init() {
		state = no;// 是否该在这初始化，因为还有双波需要检测
		maxZ1 = 0;
		maxZ2 = 0;
		ostartt = 0;
		ofinisht = 0;
		tstartt = 0;
		tfinisht = 0;
		last = 0;
		result = null;
	}

	public void no(long t, double z) {// state=no,根据z>s 改变状态，否则不变
		if (Math.abs(z) >= s) {
			changestate(oc);// 转入onecheck
			recordostart(t);// 记录开始时间
			updatemaxZ1(z);
			last = t;

		}
		// System.out.println(maxZ1+" "+maxZ2);
	}

	public void onecheck(long t, double z) {
		if (Math.abs(z) >= s) {
			updatemaxZ1(z);
			last = t;
		}// 只用更新
		else {// 结束判断
			if (isabump(t)) {// System.err.println("ofinisht:"+t);
				changestate(one);
				recordofinish(last);
				// maxZ1 = 0;
				last = 0;
			}// 符合单波 进入one状态
			else {
				init();
			}// 不符合条件，重新开始
		}
	}

	public void one(long t, double z) {// 根据当前时间到ofinisht的时间判断

		if (t - ofinisht < next_delay) { // 时域小于波间隔
			if (Math.abs(z) >= s) {
				changestate(tc);
				recordtstart(t);
				updatemaxZ2(z);
				// System.err.println(ostartt+" "+ofinisht+" "+"tstartt:"+t);
			}// 满足条件，开始检测下一个波
			else {

				last = t;
			}// 下一轮

		} else {// 只有一个波，输出并初始化
				// System.err.println(t-ofinisht);
			// System.out.println("one bump!");

			float[] bb = getbf(getbumptime());// 获得角度变化
	//		Log.e("abump", bb[0] + "----" + bb[1] + ":" + (bb[0] - bb[1]));

			result = getresult(state, maxZ1, maxZ2, bb)+" "+getd1();//加上了持续时间
	//		Log.e("abump", getresult(state, maxZ1, maxZ2, bb));
			// System.out.println(maxZ1 + " " + maxZ2);
			// System.out.println(getresult(state, maxZ1, maxZ2));
			// System.out.println(getostart()+" "+getofinish());
			// init();//这几个的状态初始化 交给allinone输出后完成
		}
	}

	public void twocheck(long t, double z) {// 这会有关于是否是一个波的输出

		if (Math.abs(z) >= s) {// 只用更新
			updatemaxZ2(z);
			last = t;
		} else {// 结束判断
			if (istbump(t)) {// 时长、极值都符合
				recordtfinish(last);
				changestate(two);
				//System.out.println("two bump!");

				float[] bb = getbf(getbumptime());
		//		Log.e("abump", bb[0] + "----" + bb[1] + ":" + (bb[0] - bb[1]));

				result = getresult(state, maxZ1, maxZ2, bb)+" "+getd1()+" "+getd2();//加上了时间
		//		Log.e("abump", getresult(state, maxZ1, maxZ2, bb));
				// System.out.println(maxZ1 + " " + maxZ2);
				// System.out.println(getostart()+" "+getofinish()+" "+gettstart()+" "+gettfinish());
				// .out.println(getresult(state, maxZ1, maxZ2));
				// init();//这几个的状态初始化 交给allinone输出后完成
			} else {
				if (t - ofinisht < next_delay) {// 没有超过时长，没有检测到第二波成立状态恢复到one，继续检测
					changestate(one);
					last = t;
					maxZ2 = 0;// 因为第二个波判断没有，重新计时，最值和开始时间都需要归0
					recordtstart(0);
				} else {// 超过时长
				//	System.out.println("one bump ");
					changestate(one);// 超过时长，没有检测到第二波成立状态恢复到one，输出
					float[] bb = getbf(getbumptime());
	//				Log.e("abump", bb[0] + "----" + bb[1] + ":"
	//						+ (bb[0] - bb[1]));
					result = getresult(state, maxZ1, maxZ2, bb)+" "+getd1(); //加上了持续时间
					// Log.e("abump",state+"  "+maxZ1+"  "+maxZ2);
	//				Log.e("abump", getresult(state, maxZ1, maxZ2, bb));
					// System.out.println(maxZ1 + " " + maxZ2);
					// System.out.println(getresult(state, maxZ1, maxZ2));
					// System.out.println(getostart()+" "+getofinish());
					// init();//这几个的状态初始化 交给allinone输出后完成
				}
			}// 不符合条件，重新开始
		}

	}

	
	
	public void checkstate(long time, double dz) {
		
		// Log.e("abump","checkstate");
		switch (state) {

		case (no):
			no(time, dz);
			break;
		case (oc):
			onecheck(time, dz);
			break;
		case (one):
			one(time, dz);
			break;
		case (tc):
			twocheck(time, dz);
			break;
		}
	}

	// 通过 state maxZ1 和maxZ2的字符判断
	public String getresult(int state2, double max1, double max2, float[] or) {
		// Log.e("abump","getresult");
		String s = null;
		float deta_or = Math.abs(or[1] - or[0]);// 后期可以考虑利用正负
		//Log.e("abump-or"," "+deta_or);
		switch (state2) {
		case (one):
			s = onebumpresult(max1, deta_or);
			break;
		case (two):
			s = twobumpresult(max1, max2, deta_or);
			break;
		// default: s="error";
		}
		return s;
	}

	// @第一个波最值 @方向变化方向先直接输出，看看情况再说，第一次不太准确
	public String onebumpresult(double max1, float or) {
		// Log.e("abump","onebumpresult");
		String d = ":" + or+ "度";

		if (max1 > 0) {// 左
			if (max1 > ht)
			{//ts.slt();
			return lt + " " + or;}// 只能判断一个较小的单波，可能是变道，也可能仅有一个小位移，待定。
			else
			{//ts.sll();
			return ll + " " + or;}// 较大单波，判断是转向
		} else {// 右
			if (Math.abs(max1) > ht)
			{//ts.srt();
			return rt + " " + or;}// 只能判断一个较小的单波，可能是变道，也可能仅有一个小位移，待定。
			else
			{//ts.srl();
			return rl + " " + or;}// 较大单波，判断是转向
		}
	}

	// @第一个波最值 @方向变化
	/*
	 * public String onebumpresult(double max1, float or) { //
	 * Log.e("abump","onebumpresult"); if (max1 > 0) { if (or >= 70 && or <=
	 * 110) return "Left turn"; else if (or >= 160 && or <= 200) return
	 * "Left U-turn"; else return "Left turn with " + or + " degree"; }//
	 * 无法判断直接输出角度 else { if (or >= 70 && or <= 110) return "Right turn"; else if
	 * (or >= 160 && or <= 200) return "Right U-turn"; else return
	 * "Right turn with " + or + " degree";// } }
	 */
	// @第一个波最值@第二个波最值@方向变化
	/*
	 * public String twobumpresult(double max1, double max2, float or) { //
	 * Log.e("abump","twobumpresult"); if (max1 > 0) if (max2 > 0) { if (or >=
	 * 70 && or <= 110) return "Left turn"; else if (or >= 160 && or <= 200)
	 * return "Left U-turn"; else return "Left turn with " + or + " degree"; }
	 * 
	 * else { if (or < 20) return "Left lane change"; else return
	 * "Left lane change with " + or + " degree"; } else if (max2 > 0) if (or <
	 * 20) return "Right lane change"; else return "Right lane change with " +
	 * or + " degree"; else { if (or >= 70 && or <= 110) return "Right turn";
	 * else if (or >= 160 && or <= 200) return "Right U-turn"; else return
	 * "Right turn with " + or + " degree"; } }
	 */
	public String twobumpresult(double max1, double max2, float or) {
		String d = ":" + or + "度";
	//	 Log.e("abump—or:"," "+or);
		if (max1 > 0)
			if (max2 > 0) {// 双上波=双左转
				if (max1 > ht && max2 > ht)
				{//ts.slt();
				return "连续大 " + lt + " " + or;}
				else
				{//ts.slt();
				return "连续 " + lt + " " + or;}
			}

			else {// 上波+下波=左变道
				if (max1 > ht && Math.abs(max2) > ht)
				{//ts.sll();
				return "强 " + ll + " " + or;}
				else
				{//ts.sll();
				return ll + " " + or;}
			}
		else {
			if (max2 > 0)// 下波+上波=右变道
				if (Math.abs(max1) > ht && max2 > ht)
				{//ts.srl();
				return "强 " + rl + " " + or;}
				else
				{//ts.srl();
				return rl + " " + or;}
			else {// 双下波=双右转
				if (Math.abs(max1) > ht && Math.abs(max2) > ht)
				{//ts.srt();
				return "连续大 " + rt + " " + or;}
				else
					{//ts.srt();
					return "连续 " + rt + " " + or;}
			}
		}
	}

	
	
	
	
	// 根据转向发生的时间和角度判断强弱
	public String grading(Tuple<Long, Long> t, float[] or) {
		long detat = t.getValue() - t.getKey();// 后面一定比前面大，时间是按序递增的,
		float detaor = Math.abs(or[1] - or[0]);
		float rate = detaor * 1000 / detat;
		String s = null;
		// 阈值还不确定

		return s;
	}

	// 初始化，每次计算完成之后清空
	public void initaccinfo() {
		accinfo.clear();
	}

	public void initgpsinfo() {
		gpsinfo.clear();
	}

	// 更新，从检测到波存在开始记录，直到波结束
	// 参数：@时间@accx@accy
	public void updateaccinfo(long t, float x, float y) {
		float[] a = { x, y };
		Tuple<Long, float[]> k = new Tuple<Long, float[]>(t, a);
		accinfo.add(k);
	}

	// 参数@时间@经度@纬度
	public void updateaccinfo(long t, double x, double y) {
		double[] a = { x, y };
		Tuple<Long, double[]> k = new Tuple<Long, double[]>(t, a);
		gpsinfo.add(k);
	}

	// 获取当前的gpsinfo
	public ArrayList<Tuple<Long, double[]>> getgpsinfo() {
		return gpsinfo;
	}

	// 获取当前的accinfo
	public ArrayList<Tuple<Long, float[]>> getaccinfo() {
		return accinfo;
	}

	// 返回波的结果,还未加入位移和角度变化的综合判断
	public String getresult() {
		return result;
	}

	// 返回波持续的起始时间
	public Tuple<Long, Long> getbumptime() {
		if (gettfinish() == 0) {
			Tuple<Long, Long> k = new Tuple<Long, Long>(ostartt, ofinisht);
			duration1=ofinisht-ostartt;
			return k;
		}// 单播返回ostartt-ofinisht
		else {
			Tuple<Long, Long> k = new Tuple<Long, Long>(ostartt, tfinisht);
			duration1=ofinisht-ostartt;
			duration2=tfinisht-tstartt;
			return k;
		}// 双波返回ostart-tfinisht
	}

	
	public long getd1(){
		return duration1;
	}
	
	public long getd2(){
		return duration2;
	}
	
	
	// 返回方向差
	public void getDvalue(long begin, long end) {

	}

	// 更新规则为，保证1000条数据上限，一旦链表满，则删除前400条数据，然后继续添加600-1000
	public void updateor(long t, float o) {

		Tuple<Long, Float> tt = new Tuple<Long, Float>(t, o);

		if (or.size() < 1000) {
			or.add(tt);
		} else {
			int i = 0;
			while (i < 400) {
				or.remove(0);
				i++;
			}
		}

	}

	
	
	
	
	// @开始-结束时间的tuple， 获取 开始--结束的朝向
	public float[] getbf(Tuple<Long, Long> t) {
		float total1 = 0, total2 = 0;
		int s = or.size();
		int mark1 = 0, mark2 = 0;
		long begin = t.getKey();
		long end = t.getValue();
		for (int i = 0; i < s; i++) {
			if (or.get(i).getKey() > begin) {
				mark1 = i - 2;
				break;
			}
		}
		int count = 0;
		// 保持j是>0，如果潜在越界，不足10个的时候，只取已有的
		for (int j = mark1; j >= 0 && j > mark1 - 10; j--) {// 从后向前
		//	Log.e(" ", " " + j);
			total1 += or.get(j).getValue();
			count++;
		}
		// 如果触发时间不对，会产生越界

		total1 = total1 / count;
		total2 = or.get(s - 1).getValue();
	//	Log.e("朝向",count+" "+total1+" "+total2);
		float[] total = new float[] { total1, total2 };
		return total;
	}

}