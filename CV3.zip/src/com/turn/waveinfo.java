package com.turn;

import java.util.ArrayList;

import android.util.Log;

public class waveinfo {

	private long wb;
	private long we;
	private float max;
	private float avg;
	private float speed;
	private boolean PN; 
	
	private ArrayList<float[]> allsensors=new ArrayList<float[]>();
	private ArrayList<Float> speedl=new ArrayList<Float>();
	
	public waveinfo(long wb,long we,float max,float avg, float speed,ArrayList<float[]> allsensors,ArrayList<Float> speedl) {
		this.wb=wb;
		this.we=we;
		this.max=max;
		this.avg=avg;
		this.speed=speed;
		//this.PN=PN;
		this.allsensors=allsensors;
		this.speedl=speedl;
	}
	
	public void showsensorinfo(){
	//	if(allsensors.size()==speedl.size()){//室内测试时没有gps，单独处理两维数据算了
		int i=allsensors.size();
		for(int j=0;j<i;j++){
			String s="";
			for(int k=0;k<allsensors.get(j).length;k++)s+=" "+allsensors.get(j)[k];
			Log.e("In-waveinfo",j+"："+s);
		}
		//}
		//Log.e("In-waveinfo",allsensors.size()+" "+speedl.size());
	}
	
	public ArrayList<String> sensorinfo2list(){
		ArrayList<String> sl=new ArrayList<String>();
		int i=allsensors.size();
		for(int j=0;j<i;j++){
			String s="";
			for(int k=0;k<allsensors.get(j).length;k++)s+=" "+allsensors.get(j)[k];
			sl.add(j+":"+s);
			//	Log.e("In-waveinfo",j+"："+s);
		}
		return sl;
	}
	
	public ArrayList<float[]> getallsensors(){
		return this.allsensors;
	}
	
	public ArrayList<Float> getspeedl(){
		return this.speedl;
	}
	
	public ArrayList<String> speedinfo2list(){
		ArrayList<String> sl=new ArrayList<String>();
		int i=speedl.size();
		for(int j=0;j<i;j++){
			sl.add(speedl.get(j).toString());
		}
		return sl;
	}
	
	
	public long getdur(){
		return we-wb;
	}
	
	public float getwe(){
		return we;
	}
	
	public float getwb(){
		return wb;
	}
	
	public float getavg(){
		return avg;
	}
	
	public float getspeed(){
		return speed;
	}
	
	public float getmax(){
		return max;
	}
	
	public boolean getPN(){
		if(avg>0)return true;
		else return false;
	}
}
