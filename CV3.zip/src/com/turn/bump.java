package com.turn;

//为论文VSense_MobiSys2015的算法，对状态识别进改进后的类为abump
public class bump {
	//几种状态
	final static int no=1; //没有
	final static int oc=2;//单波待检测
	final static int one=3;//单波出现
	final static int tc=4;//双波待检测
	final static int two=5;//双波出现
	
	private static double s=0.08;//最小转角 可修改
	private static double h=0.14;//最大转角
	private static int dwell=2000;//3372，单个波持续时间
	private static int next_delay=1800;//ms 连续两个波的间隔时间
	private static int state=no;//no=没有。one=一个波，two=两个波
	private static double maxZ=0;
	static long ostartt=0;//1起始时间
	static long ofinisht=0;//1起始时间
	static long tstartt=0;//2起始时间
	static long last=0;
	
	//static long finisht=0;
	
	public static void changestate(int s){
		state=s;
	}
	
	
	public int getstate(){
		return state;
	}
	//单波开始
	public static void recordostart(long time){		
		ostartt=time;
	}
	
	//单波结束
		public static void recordofinish(long time){		
			ofinisht=time;
		}
	
		
		
		
	//每次更新maxZ
	public static void updatemaxZ(double dz){
		 if(maxZ<Math.abs(dz))maxZ=Math.abs(dz);
		//if(dz>0&&dz>maxZ)maxZ=dz;
		//else if(dz<0&&dz<maxZ)maxZ=dz;
	}
	
	public static boolean isabump(long t){
	return ((t-ostartt>dwell)&&(maxZ>=h));	
	}
	
	
	public static boolean istbump(long t){
	return ((t-tstartt>=dwell)&&(maxZ>=h));	
	}
	
	
	public static void init(){
		state=no;//是否该在这初始化，因为还有双波需要检测
		maxZ=0;
		ostartt=0;
		ofinisht=0;
		tstartt=0;
		last=0;
	}
	
    

public static void no(long t,double z){//state=no,根据z>s 改变状态，否则不变
	if(Math.abs(z)>=s){
	changestate(oc);//转入onecheck
	recordostart(t);//记录开始时间
	updatemaxZ(z);
	last=t;
	}	
	}



public static void onecheck(long t,double z){
	if(Math.abs(z)>=s){updatemaxZ(z);last=t;}//只用更新
	else{//结束判断
		if(isabump(t)){//System.err.println("ofinisht:"+t);
			changestate(one);
			recordofinish(last);
			maxZ=0;
			last=0;
			}//符合单波 进入one状态
		else {init();}//不符合条件，重新开始
	}
}

public static void one(long t,double z){//根据当前时间到ofinisht的时间判断
	
	if(t-ofinisht<next_delay){ //时域小于波间隔		
		if(Math.abs(z)>=s){
			changestate(tc);
			tstartt=t;
		//System.err.println(ostartt+" "+ofinisht+" "+"tstartt:"+t);
		}//满足条件，开始检测下一个波
		else {updatemaxZ(z);last=t;}//下一轮
		
	}
	else {//只有一个波，输出并初始化
		//System.err.println(t-ofinisht);
		System.out.println("one bump!"+t);
		init();
	}
}

public void twocheck(long t,double z){//这会有关于是否是一个波的输出
	
	if(Math.abs(z)>=s){updatemaxZ(z);last=t;}//只用更新
	else{//结束判断
		if(istbump(t)){
			changestate(two);
		System.out.println("two bump!"+t);
		init();
		}//符合单波 进入one状态
		else { 
			if(t-ofinisht<next_delay){changestate(one);last=t;maxZ=0;}//如果这时候时间片还没到间隔		
			else{
			System.err.println(t-ofinisht);
			System.err.println(ostartt+" "+ofinisht+" "+tstartt+" "+t);
			System.out.println("one bump "+t);
			//System.err.println(t-tstartt+" "+maxZ);
			//System.err.println(t-ofinisht);
			init();}}//不符合条件，重新开始
	}
	
	
}

	
}
