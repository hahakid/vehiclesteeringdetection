package com.turn;

import java.util.ArrayList;

//检波算法的检测基本单位，包含最基本的波信息，以及参数获取方法
public class wave {

	//private float dmin;//波的最小值，可能不需要，因为检测波存在放在multiwave，通过最小值来确定
	private float dmax;//波的最大值
	private float davg;//波的均值 
	private long wb;//波的开始时间
	private long we;//波的结束时间
	private long wduration;//波的持续时间
	private boolean pn;//波的正负性
	private ArrayList<Float> dzlist;
	
	private ArrayList<Float> speed; //先只考虑转向前的速度，获取一次
	private ArrayList<float[]> allsensors;
	
	//初始化所有值
	public void init(){
	//	dmin=10;
		dmax=0;
		davg=0;
		wb=0;
		we=0;
		wduration=0;
		pn=false;
		speed=new ArrayList<Float>();
		dzlist=new ArrayList<Float>();
		allsensors=new ArrayList<float[]>();
	}
	
	//获取当前wave全部传感器数值
	public ArrayList<float[]> getas(){
		return allsensors;
	}
	
	public void updateas(float[] a){
		allsensors.add(a);
	}
	
	public String astoString(){
		String s=null;
		if(allsensors.isEmpty())return null;
		else {
			for(int i=0;i<allsensors.size();i++){
				s+=allsensors.get(i)[0]+" "+allsensors.get(i)[1]+" "+allsensors.get(i)[2]+" "+allsensors.get(i)[3]+" "+allsensors.get(i)[4]+" "+allsensors.get(i)[5]+" "+allsensors.get(i)[6]+"\n";
				
			}//s+=allsensors.get(i).toString()+"\n";
			return s;
		}
	}
	
	
	
	//实时更新单个波
	public void updatewave(float dz){
		dzlist.add(dz);
//		if(dz<dmin)dmin=dz;
		if(dz>0&&dz>dmax)dmax=dz;//正
		else if(dz<0&&dz<dmax)dmax=dz;//负
	}
	
	public void updatespeed(float s){
		speed.add(s);
	}
	

	public void setdavg(){
		int size=dzlist.size();
		float total=0;
		for(float d:dzlist){
			total+=d;
		}
		
		davg=total/size;
		setpn();
	}
	
	public void setwb(long b){
		wb=b;
	}
	
	//把值的设定都放入获取结束时间之后完成 (除开始时间)，先这样吧，可能开始也放里面
	public void setwe(long e){
		we=e;
		setwduration();//直接在获取结束时间后生成
		setdavg();//获取均值
	}
	
	//计算波持续时间
	private void setwduration(){
		wduration=we-wb;
	}
	
	//获取当前波的数值
	public ArrayList<float[]> getallsensors(){
		return this.allsensors;
	}
	
	private void setpn(){
		if(davg>0)pn=true;
		else pn=false;
	}
	
	//获取值
	public long getwb(){
		return wb;
	}
	
	public long getwe(){
		return we;
	}
	
	public float getdmax(){
		return dmax;
	}
	
	public long getwduration(){
		return wduration;
	}
	
	public boolean getpn(){
		return pn;
	}
	
	public ArrayList<Float> getspeed(){
		return speed;
	}
	public float getavg(){
		return davg;
	}
	
}
