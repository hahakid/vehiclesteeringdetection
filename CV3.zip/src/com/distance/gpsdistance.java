package com.distance;

import java.util.ArrayList;

import com.util.Tuple;
//gps经纬度计算位移
public class gpsdistance {
	
	/*累计每个时间片内距离的函数，以及两个GPS经纬度之间的相对位移量*/

	ArrayList<Tuple<Long, double[]>> gpscoords = new ArrayList<Tuple<Long, double[]>>();

	public void updategps(long t, double x, double y) {
		double[] coords = new double[2];
		coords[0] = x;//经度
		coords[1] = y;//维度
		Tuple<Long, double[]> tt = new Tuple<Long, double[]>(t, coords);
		if(gpscoords.size()<500){//gps更新频率是1s，存储500条近十分钟了
		gpscoords.add(tt);}
		else {
			gpscoords.remove(0);
			gpscoords.add(tt);
		}
	}

	
	public void init(){gpscoords.clear();}
	
	
	// 由于可能是非同一的时钟，计算时取第一个小于于t1到 第一个大于t2的时间之间的进行计算.因为误差是s级别的，可以忽略
	//逐项计算t1-t2之间的距离总和。
	public double getdistanceplus(long t1, long t2) {
		if (t1 < t2) {
			int begin = 0, end = 0;//
			boolean flag1 = false, flag2 = false;
			double totaldistance = 0;
			for (int i = 0; i < gpscoords.size() - 1; i++) {
				long j = gpscoords.get(i).getKey();
				if (!flag1 && j > t1) {
					begin = i;
					flag1 = true;
				}
				// 参数顺序分别是x[t-1] x[t] y[t-1] y[t]
				if (flag1)
					totaldistance += gpsdistance(
							gpscoords.get(i).getValue()[0], gpscoords
									.get(i + 1).getValue()[0], gpscoords.get(i)
									.getValue()[1], gpscoords.get(i + 1)
									.getValue()[1]);
				if (!flag2 && j > t2) {
					end = i;
					flag2 = true;
				}
				if (flag1 && flag2)
					break;
			}

			return totaldistance;

		}
		return 0;
	}

	//直接计算t1(x,y) 和t2(x,y)的距离
	public double[] getsimpledistance(long t1, long t2) {
		if (t1 < t2) {
			int begin = 0, end = 0;//在gpscoords中的位置
			boolean flag1 = false, flag2 = false;
			
			for (int i = 0; i < gpscoords.size() - 1; i++) {
				long j = gpscoords.get(i).getKey();
				if (!flag1 && j > t1) {
					begin = i;
					flag1 = true;
				}
				// 参数顺序分别是x[t-1] x[t] y[t-1] y[t]
				if (!flag2 && j > t2) {
					end = i;
					flag2 = true;
				}
				if (flag1 && flag2)
					break;
			}
			
			double[] totaldistance=new double[]{latitude2ydis(gpscoords.get(begin).getValue()[1],gpscoords.get(end).getValue()[1]),
			longitude2xdis(gpscoords.get(begin).getValue()[0],gpscoords.get(end).getValue()[0])
			};
			return totaldistance;

		}
		else return null;
	}
	
	// 两点之间的真实距离,因为有平方不关心先后顺序造成的负数
	// 另外，考虑连续两个点的gps坐标可能无变化，预先处理直接返回0
	public double gpsdistance(double latitude1, double latitude2,
			double longitude1, double longitude2) {
		if (latitude1 == latitude2 && longitude1 == longitude2)
			return 0;
		else {
			double a = rad(latitude1) - rad(latitude2);
			double b = rad(longitude1) - rad(longitude2);
			double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2)
					+ Math.cos(latitude1) * Math.cos(latitude2)
					* Math.pow(Math.sin(b / 2), 2)));
			s *= 6378137;
			return Math.round(s * 10000) / 10000;//小数点后4位
		}
	}

	public double rad(double x) {
		return x * Math.PI / 180;
	}

	// 下面两个装换函数采用Miller cylindrical projection，将经纬度坐标分别转化为平面坐标系的xy
	// 维度2平面坐标y
	public double latitude2y(double l) {
		double L = 6381372 * Math.PI * 2; // 地球周长

		double H = L / 2; // y轴约等于周长一半
		double mill = 2.3; // 米勒投影中的一个常数，范围大约在正负2.3之间

		double y = l * Math.PI / 180; // 将纬度从度数转换为弧度
		// 这里是米勒投影的转换
		y = 1.25 * Math.log(Math.tan(0.25 * Math.PI + 0.4 * y));
		// 这里将弧度转为实际距离
		y = (H / 2) - (H / (2 * mill)) * y;
		return  y;
	}

	// 经度2平面坐标x
	public double longitude2x(double l) {
		double L = 6381372 * Math.PI * 2; // 地球周长
		// double x = ( L / 2 ) + ( L / (2 * Math.PI) ) * l * Math.PI / 180;
		double x = (L / 2) + L * l / 360;// 化简得
		return  x;
	}

	// 直接用纬度求相对位移，公式通过前面两个函数进行化简, ydisplacement
	public double latitude2ydis(double l1, double l2) {
		double L = 6381372 * Math.PI * 2; // 地球周长
		double H = L / 2; // y轴约等于周长一半
		double mill = 2.3; // 米勒投影中的一个常数，范围大约在正负2.3之间
		return  ((1.25 * H) / (2 * mill) * Math.log((Math
				.tan((l1 * 0.4 / 180 + 0.25) * Math.PI) / (Math
				.tan((l2 * 0.4 / 180 + 0.25) * Math.PI)))));
	}

	// 直接用经度求相对位移，公式通过前面两个函数进行化简，xdisplacement
	public double longitude2xdis(double l1, double l2) {
		double L = 6381372 * Math.PI * 2; // 地球周长
		return (L * (l2 - l1) / 360);
	}


	
	
	
}
