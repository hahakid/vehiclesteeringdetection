package com.distance;

import java.util.ArrayList;

import com.util.Tuple;
import com.util.statistic;
//import java.util.Random;


/*周期更新 周期为60s左右
 * 
 * */
public class distance{
	 int count=0;
	private final  int period=60;//计算周期
	
	private static ArrayList<Double> latitude= new ArrayList<Double>();
	private static  ArrayList<Double> longitude= new ArrayList<Double>();
	//保存全部gps地理信息
	private static ArrayList<Tuple<Double,Double>> gpsl=new ArrayList<Tuple<Double,Double>>();
	
	private static double totaldistance=0;
	
	private  double midx,midy;
	
	statistic s=new statistic();
	
	//用于每秒更新的函数
	private static double totaldbys=0;
	private double lastlatitude=0,lastlongitude=0;
	
	
	
	
	public double gettotal(){
		return totaldistance;
	}
	//每次更新完清空
	private  void initcoord(){
		latitude.clear();
		longitude.clear();
	}
	
	//用了有问题
	private  double[][] preprocess(ArrayList<Double> lit,ArrayList<Double> lon){
		double decimalx=0,decimaly=0;//整数部分
		double[][] result=new double[2][period];
		int l=lit.size();
		for(int i=0;i<l;i++){
		//	System.out.println(count);count++;
			double lx=lit.get(i);
			double ly=lon.get(i);
			if(lx!=0){
			decimalx=lx-(int)lx;
			result[0][i]=decimalx;}//获取的经纬度精确到小数点后6位
			else result[0][i]=0;
			if(ly!=0){
			decimaly=ly-(int)ly;
			result[1][i]=decimaly;}
			else result[1][i]=0;
		}
		return result;
	}
	
	
	//外部函数通过不断更新此函数来驱动里程计算
	public void updatecoord(double x,double y){
		if(latitude.size()<period){//一分钟更新一次
			latitude.add(x);
			longitude.add(y);}
		else{//先计算再更新
			s.updatetotaldistance(localdistance(latitude,longitude));
			int size=latitude.size();
			midx=latitude.get(size-1);
			midy=longitude.get(size-1);
			initcoord();
			latitude.add(midx);
			longitude.add(midy);
			latitude.add(x);
			longitude.add(y);
		}
	
	}
	
	
	//每秒更新，采用另一个全程计数器
	public void updatecoordbys(double x,double y){
	//totaldbys+=	gpsdistance(x,lastlatitude,y,lastlongitude);
	s.updatenewtotaldistance(gpsdistance(x,lastlatitude,y,lastlongitude));		
	lastlatitude=x;lastlongitude=y;
	}
	
	
	
	public double localdistance(ArrayList<Double> x,ArrayList<Double> y){
	
		int lengthofx=x.size();
		double ld=0;
		for(int i=0;i<lengthofx-1;i++){
		//	System.out.println();
		//	System.out.println(gpsdistance(xx.get(i),xx.get(i+1),yy.get(i),yy.get(i+1)));
			ld+=gpsdistance(x.get(i),x.get(i+1),y.get(i),y.get(i+1));					
			
		}
		totaldistance+=ld;
		return ld;
		/*	if(g.size()==1){//直线，只算首尾
			int size=k[0].length;
		//	System.out.println(k[0][0]+" "+k[1][0]+" "+k[0][size-1]+" "+k[1][size-1]);
		//	System.out.println(gpsdistance(k[0][0],k[1][0],k[0][size-1],k[1][size-1]));
			totaldistance+=gpsdistance(k[0][0],k[0][size-1],k[1][0],k[1][size-1]);	
		}
		else{
			int length=g.size();
			for(int i=0;i<length-2;i++){
				int b=g.get(i),e=g.get(i+1);
			//	System.out.println(k[0][b]+" "+k[1][e]+" "+k[0][b]+" "+k[1][e]);
			//	System.out.println(gpsdistance(k[0][b],k[1][e],k[0][b],k[1][e]));
				totaldistance+=gpsdistance(k[0][b],k[0][e],k[1][b],k[1][e]);		
			}
			
		}*/
		
	}
	

	
	// 两点之间的真实距离,因为有平方不关心先后顺序造成的负数
	// 另外，考虑连续两个点的gps坐标可能无变化，预先处理直接返回0
	//通过gps经纬度坐标计算 现实距离 输入x1，x2，y1，y2
	public  double gpsdistance(double latitude1, double latitude2,
			double longitude1, double longitude2) {
		if (latitude1 == latitude2 && longitude1 == longitude2)
			return 0;
		else {
			double a = rad(latitude1) - rad(latitude2);
			double b = rad(longitude1) - rad(longitude2);
			double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2)
					+ Math.cos(latitude1) * Math.cos(latitude2)
					* Math.pow(Math.sin(b / 2), 2)));
			s *= 6378137;
			return Math.round(s * 10000) / 10000;//小数点后4位
		}
	}

	public  double rad(double x) {
		return x * Math.PI / 180;
	}
	
	

}
