package com.distance;

import java.util.ArrayList;

import com.util.Tuple;

import android.util.Log;
//传感器积分位移,不准确放弃
public class accdistance {

	double ydisplacement,xdisplacement,displacement;
	double xspeed,yspeed,speed;
	ArrayList<Tuple<Long,float[]>>  info=new ArrayList<Tuple<Long,float[]>>();
	
	//每次调用，进行更新
	public void update(long t,float x,float y){
		float[] a={x,y};
		Tuple<Long,float[]> k=new Tuple<Long,float[]>(t,a);
		
		if(info.size()<6000)info.add(k);//每次保留当前6000个时间片的数据
		else {info.remove(0);info.add(k);}
	}
	
	
	public void initdisplacement(){//
		ydisplacement=0;xdisplacement=0;displacement=0;
	}
	public void initspeed(){//
		yspeed=0;xspeed=0;speed=0;
	}
	
	//获取时间片从t1-t2之间的水平和
	public double[] getsimpledistance(long t1, long t2) {
		//Log.e("accdistance","时间："+t1+"  "+t2);
		if (t1 < t2) {
			int begin = 0, end = 0;//在gpscoords中的位置
			boolean flag1 = false, flag2 = false;
			ArrayList<Tuple<Long,float[]>> temp=new ArrayList<Tuple<Long,float[]>>();
			for (int i = 0; i < info.size() - 1; i++) {
				long j = info.get(i).getKey();
				if (!flag1 && j > t1) {
					begin = i;
					flag1 = true;
				}
				if(flag1){temp.add(info.get(i));
				//Log.e("accdistance",info.get(i).getKey()+" ");
				}
				// 参数顺序分别是x[t-1] x[t] y[t-1] y[t]
				if (!flag2 && j > t2) {
					end = i;
					flag2 = true;
				}
				if (flag1 && flag2)
					break;
			}
			//Log.e("accdistance",+temp.);
			//Log.e("accdistance","距离："+calculation(temp)[0]+"  "+calculation(temp)[1]);
			return calculation(temp);

		}
		else return null;
	}
	
	
	
	
	
	
	//starttime 和endtime 为采样的时间戳，slot为
	public double[] calculation(ArrayList<Tuple<Long,float[]>> i){
		int l=i.size();
		initdisplacement();
		initspeed();
		for(int j=0;j<l-1;j++)
		{	
			Tuple<Long,float[]> k1=i.get(j),k2=i.get(j+1);
			float[] a=k1.getValue();//a[0]=ax a[1]=ay
			float[] b=k2.getValue();//a[0]=ax a[1]=ay
			double t=(double)(k2.getKey()-k1.getKey())/1000.0;//时间上要ms——>s
		  //  Log.e("accdistance"," time:"+t);
			xspeed+=t*a[0];//t*(b[0]-a[0])
			yspeed+=t*a[1];//t*(b[1]-a[1])
			speed+=(float) Math.sqrt(xspeed*xspeed+yspeed*yspeed);
			xdisplacement+=xspeed*t;
			ydisplacement+=yspeed*t;
			displacement=speed*t;
		}
		double[] tem=new double[]{xdisplacement/1000,ydisplacement/1000};
		//Log.e("acc",tem[0]+" "+tem[1]);
		return tem;
	}
	
	
	//返回当前的  x轴  相对位移（垂直前进方向）
	public double xdisplacement(){
		return xdisplacement;
	}
	//返回当前的  y轴 相对位移  （前进方向）
	public double ydisplacement(){
		return ydisplacement;
	}
	//返回当前的相对位移
	public double displacement(){
		return displacement;
	}
	

}
