package com.speed;

import java.util.ArrayList;

import com.util.Tuple;

public class GPSspeed {//km/h or m/s
	//update frequency is 1Hz
	float lastspeed=0;
	float acc=0;//加速度是根据gps速度计算的，与传感器无关
	long lt=0;//上个时间片
	ArrayList<Tuple<Long,float[]>> recorder=new ArrayList<Tuple<Long,float[]>>();
	
	
	public String update(long t,float speed){
		updaterecorder(t,speed,acc);//先更新
		String state;
		
		 float detaspeed=speed-lastspeed;
		 long detat=t-lt;
		 acc=1000*(detaspeed)/(detat);
		 
		if(speed==0) {
			if(acc==0)state="stop";
			else if(acc<0)state="decelerate";
			else state="accelerate";
		}
		else{
			if(acc==0)state=null;//匀速行驶，不记录状态
			else if(acc<0)state="decelerate";
			else state="accelerate";		
		} 
		lt=t;//最后更新
		lastspeed=speed;
		return state;
	}
	
	//@时间@速度@加速度
	private void updaterecorder(long t,float s,float a){
		float[] v=new float[]{s,a};
		Tuple<Long,float[]> tup=new Tuple<Long,float[]>(t,v);
		recorder.add(tup);	
	}
	
	public float getacc(){
		return acc;
		
	}
}
