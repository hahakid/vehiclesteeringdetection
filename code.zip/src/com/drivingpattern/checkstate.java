package com.drivingpattern;
//空状态不输出

import java.util.LinkedList;
import android.util.Log;

//传感器阈值检测转向和加减速
public class checkstate {
	private LinkedList<float[]> l_info, c_info; // 上一个last
	private float cxchange;
	private float axchange;
	private String turnstate;// 转向状态
	private String accstate;// 加速状态
	//private String orientstate;// 方向
	
	
	
	//
	public void initqueue(){
		l_info = new LinkedList<float[]>();
		c_info = new LinkedList<float[]>();
	}
	
	private boolean isaccchanged(LinkedList<float[]> f1, LinkedList<float[]> f2) {
		int i = 1;// 加速度y是1
		float avg1 = 0, avg2 = 0;
		for (float a : f1.get(i))
			avg1 = avg1 + a;
		avg1 = avg1 / f1.get(i).length;
		for (float a : f2.get(i))
			avg2 = avg2 + a;
		avg2 = avg2 / f2.get(i).length;
		axchange = Math.abs(avg1 - avg2);
		if (Math.abs(avg1 - avg2) > 3) {// 相当于1s加速到10马
			return true; // 变化了
		} else
			return false; // 没变化
	}
	
	// c_info的0-ax 1-ay 2-dz 3-cx
	public void updata_info(float[] a) {// 采样频率提高一倍 10次均值相当于0.5ms的
			if (c_info.size() <= 5)
				c_info.add(a);// 原先为10
			else {
			//Log.e("checkstate", c_info.toString()+"    "+l_info.toString());
				// compare
				if (!l_info.isEmpty()) {
					if (isorientalchanged(l_info, c_info))
						turnstate = checkturn(a[0],a[1],a[2]);
					else
						turnstate = null;
					if (isaccchanged(l_info, c_info))
						accstate = checkacc(a[1],a[2]);
					else
						accstate = null;
				}
				l_info.clear();
				for (int i = 0; i < c_info.size(); i++)
					l_info.add(c_info.get(i));
				c_info.clear();
				c_info.add(a);
			}
		}
		
		//返回 前进 方向的状态，在updata_info之后调用
		public String getaccstate(){
			return accstate;
		}
		//返回 水平 方向的状态，在updata_info之后调用
		public String getturnstate(){
			return turnstate;
		}
		
		
		public String checkturn(float ax,float ay,float dz) {
			// 强度
			String s = "it's a/an ";

			float average_ax = 0, average_ay = 0;
			for (float[] a : c_info) {
				average_ay += a[1];
				average_ax += a[0];
			}

			average_ax = average_ax / c_info.size();
			average_ay = average_ay / c_info.size();

			// 右转ax>0&ay>0 | dz<-0.1
			if (ax > 0 && ay > 0 && dz < -0.1) {
				String a = "right turn";
				if (average_ax <= 1.5 && average_ay > 2)
					s = s + "normal " + a;
				else if (average_ax > 1.5 && average_ax < 2.5 && average_ay > 4)
					s = s + "smooth " + a;
				else if (average_ax >= 2.5 && average_ax < 4 && average_ay > 6)
					s = s + "aggressive " + a;
				else
					s = s + "dangerous " + a;
			}
			// 左转ax<0&ay>0 | dz>0.1
			if (ax <= 0 && ay > 0 && dz > 0.1) {
				String a = "left turn";
				if (average_ax >= -1.5)
					s = s + "normal " + a;
				else if (average_ax < -1.5 && average_ax > -2.5 && average_ay > 2)
					s = s + "smooth " + a;
				else if (average_ax <= -2.5 && average_ax > -4 && average_ay > 4)
					s = s + "aggressive " + a;
				else
					s = s + "dangerous " + a;
			}
			// Log.e("log", "转向外");
			if (s.length() < 20) { // 如果加速度并没有检测出转向，使用角速度检测
				// Log.e("log", "dz内");
				if (dz > 0.1)
					if (dz > 1)
						s = s + "normal left turn";
					else if (dz >= 1 && dz < 2)
						s = s + "smooth left turn";
					else if (dz >= 2 && dz < 4)
						s = s + "aggressive left turn";
					else
						s = s + "dangerous left turn";

				// 左转ax<0&ay>0 | dz>0
				if (dz <= -0.1)
					if (dz > -1)
						s = s + "normal right turn";
					else if (dz > -2 && dz <= -1)
						s = s + "smooth right turn";
					else if (dz > -4 && dz <= -2)
						s = s + "aggressive right turn";
					else
						s = s + "dangerous right turn";
			}

			if (s.length() < 20)
				s = null;
			return s;
		}

		public String checkacc(float ay,float dz) {
			// 强度
			String s = "it's a/an ";
			float average_ay = 0, average_ax = 0,average_dz=0;
			for (float[] a : c_info) {
			//	average_ay += a[1];// acc_y-1
				average_ax += a[0];// acc_x-0
				average_dz += a[2];
			}
			//average_ay = average_ay / c_info.size();
			average_ax = average_ax / c_info.size();
			average_dz=average_dz/c_info.size();
			if (average_dz > -0.3 && average_dz < 0.3&&average_ax<=1&&average_ax>=-1) {
				if (ay > 0)
					if (ay < 2)
						s = s + "normal forward driving";
					else if (ay >= 2 && ay < 4)
						s = s + "smooth forward driving";
					else if (ay >= 4 && ay < 6)
						s = s + "aggressive forward driving";
					else
						s = s + "dangerous forward driving";

				if (ay <= 0)
					if (ay > -2)
						s = s + "normal break";
					else if (ay <= -2 && ay > -4)
						s = s + "smooth break";
					else if (ay <= -4 && ay > -6)
						s = s + "aggressive break";
					else
						s = s + "dangerous break";
			}
			if (s.length() < 20)
			{	s=null;
				return s;}
			else return s;
		}

		
		// 用均值 判断是否变化 0-ax,1-ay,2-dz, 3-com（3没有设定极值）
		private boolean isorientalchanged(LinkedList<float[]> f1,
				LinkedList<float[]> f2) {
			int i = 3;// 方向是3
			float avg1 = 0, avg2 = 0;
			for (float a : f1.get(i))
				avg1 = avg1 + a;
			avg1 = avg1 / f1.size();
			for (float a : f2.get(i))
				avg2 = avg2 + a;
			avg2 = avg2 / f2.size();
			cxchange = avg1 - avg2;
			if (Math.abs(avg1 - avg2) > 10) {// 角度均值变化>50

				return true; // 变化了
			} else
				return false; // 没变化
		}

}
