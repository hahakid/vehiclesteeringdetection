package com.drivingpattern;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.drivingpattern.R;
import com.log.sensorlog;
import com.speed.GPSspeed;
import com.turn.abump;
import com.turn.tbump;
import com.util.Triple;
import com.DTW.DTWDistance;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.LocationClientOption.LocationMode;

/**
 * 
 * @author Windows
 * 
 */
public class core extends Activity implements SensorEventListener {
	//时间制式
	//SimpleDateFormat fd = new SimpleDateFormat("yyyyMMdd "); // 年-月-日:文件名
	SimpleDateFormat ft = new SimpleDateFormat("HH:mm:ss：   "); // 时-分-秒
	//SimpleDateFormat fa = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss：   "); // 时-分-秒
	// 把手机先按正反上下左右 分为abcdef面
	private static String up;
	private static String down;
	private static String front;
	private static String back;
	private static String left;
	private static String right;
	java.text.DecimalFormat df = new java.text.DecimalFormat("###.##");
	private boolean flag = false;// 检测
	
	public String bumpresult=null; 

	checkstate mystate=new checkstate();//简单阈值检测
	
	private DTWDistance DTW;// 计算DTW距离
	//private LinkedList<float[]> l_info, c_info; // 上一个last

	//private float gpsspeed = 0;
	private long gpstimer;
	GPSspeed mgs=new GPSspeed();
	
	float[] max;// 几个传感器的最大值,用于分级,分别是40、20、40
	//abump mybump = new abump();// 检测角速度的波形
	tbump mybump = new tbump();// 检测角速度的波形

	private TextView cstate, LocationResult, logMsg, gps_speed;

	// 传感器类型变量
	private Sensor mAccelerometer;// 加速度
	private Sensor mGravity;// 重力
	private Sensor mGyroscope;// 加速度
	private Sensor mCompass;// 磁场

	// 存放传感器参数
	float[] accelerometerValues = new float[3]; // 存放加速度三维
	float[] magneticFieldValues = new float[3];// 磁场，罗盘
	float[] gravityValues = new float[3]; // 存放重力三维
	float[] gyroscopeValues = new float[3];// 存放陀螺仪转角

	private float ax = 0, ay = 0;// 存放加速度x,y
	// private float gx = 0, gy = 0, gz = 0;// 存放重力三维
	private float dz = 0;// 存放陀螺仪转角
	private float cx = 0;// 磁场，罗盘
	private String as, gs, ds, cs;

	private SensorManager mSensorManager;

	// private float[] dis=new float[4];

	// 时间控制的,单位毫秒ms 1000ms=1s
	private long lastUpdateTime1, lastUpdateTime2, begintime;// 系统初始化时间
	private static final int UPTATE_ORIENTATION_TIME = 100;// 0.1s左右检测一次方向变化,1s太长
	// 缩小采样间隔
	private static final int UPTATE_INTERVAL_TIME = 20;

	// private static final int UPTATE_INTERVAL_TIME_1 = 500;

	private accdistance md1=new accdistance();//传感器积分位移
	private gpsdistance md2=new gpsdistance();//gps距离

	
	
	private String mTest1 = "acceleration";
	private String mTest2 = "deceleration";
	private String mTest3 = "turnleft";
	private String mTest4 = "turnright";
	private String mTest5 = "U-turn";
	private String mTest6 = "L-lane";
	private String mTest7 = "R-lane";

	private Button mButton;
	private Button startLocation;// 开启/停止定位按键

	private int timecount;// 时间片

	// 定位变量
	public LocationClient mLocationClient;// 定位服务的客户端
	public MyLocationListener mMyLocationListener;
	public Vibrator mVibrator;

	// 输出日志文件
	sensorlog senlog = new sensorlog();
	sensorlog orientlog = new sensorlog();
	sensorlog threshold = new sensorlog();
	sensorlog handstatelog = new sensorlog();
	sensorlog gpsllog = new sensorlog();//gps-location
	sensorlog gpsslog = new sensorlog();//gps-speed
	sensorlog autobumplog = new sensorlog();
	
	//private int delay=0;
	//private boolean dalayflag=false;

	// 新转向, 存储 @时间 @方向 @角速度-dz
	List<Triple<Integer, Float, Float>> op = new ArrayList<Triple<Integer, Float, Float>>();

	private void initMax() {
		max = new float[3];
		max[0] = 40;// 加速度极值变化[-20,20]
		max[1] = 20;// 重力加速度极值变化[-9.8,9.8]
		max[2] = 40;// 转角极值变化[-20,20]
	}

	public String getinfo(LinkedList<float[]> a) {
		String s = "";
		for (float[] b : a) {
			s = s + "|" + b[0] + "|" + b[1] + "|" + b[2] + "|" + b[3];
		}
		return s;
	}

	// 获取list的均值, 为队列的第t维
	public float getaverage(LinkedList<float[]> q, int t) {
		float average = 0, sum = 0;
		int count = 0;
		for (float[] a : q) {
			sum = sum + a[t];
			count++;
		}
		average = sum / count;
		return sum;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {// 相当于初始化函数，其余类初始化在这

		super.onCreate(savedInstanceState);
		mystate.initqueue();//初始化，简单阈值检测


		DTW = new DTWDistance();
		// 加入之后，防止系统休眠
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_main);

		mLocationClient = new LocationClient(this.getApplicationContext());
		mMyLocationListener = new MyLocationListener();
		mLocationClient.registerLocationListener(mMyLocationListener);

		mVibrator = (Vibrator) getApplicationContext().getSystemService(
				Service.VIBRATOR_SERVICE);

		// mLocationClient =
		// ((LocationApplication)getApplication()).mLocationClient;
		LocationResult = (TextView) findViewById(R.id.gps_info);
		gps_speed = (TextView) findViewById(R.id.gps_speed);
		// ((LocationApplication)getApplication()).mLocationResult =
		// LocationResult;
		initGPS();

		initSensors();// 初始化控件
		logbyhand();// 手动添加转向日志
		initlog();
		inittimers();
	}
	//初始化各计时器 
	public void inittimers(){
		gpstimer = begintime = lastUpdateTime2 = lastUpdateTime1 = System
				.currentTimeMillis();
		timecount = 0;
		
	}
	
	
	
	
	// 初始化GPS
	private void initGPS() {
		startLocation = (Button) findViewById(R.id.GPS);
		startLocation.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				InitLocation();
				if (startLocation.getText().equals(
						getString(R.string.startlocation))) {

					mLocationClient.start();
					startLocation.setText(getString(R.string.stoplocation));
				} else {
					mLocationClient.stop();
					startLocation.setText(getString(R.string.startlocation));
					logMsg("loaction stop");
				}
			}
		});
	}

	// 日志初始化
	private void initlog() {
		senlog.initfile("atest", "sensor");
		orientlog.initfile("atest", "orientation");
		threshold.initfile("atest", "thresholdcheck");
		handstatelog.initfile("atest", "handstate");
		gpsllog.initfile("atest", "gpsl");
		gpsslog.initfile("atest", "gpss");
		autobumplog.initfile("atest", "bumpcheck");
	}

	// 百度定位初始化
	private void InitLocation() {
		LocationClientOption option = new LocationClientOption();
		option.setLocationMode(LocationMode.Hight_Accuracy);// 设置定位模式
		option.setCoorType("bd09ll");// 返回的定位结果是百度经纬度,默认值gcj02
		option.setScanSpan(1000);// 设置发起定位请求的间隔时间为5000ms
		option.setIsNeedAddress(true);// 返回的定位结果包含地址信息
		option.setNeedDeviceDirect(true);// 返回的定位结果包含手机机头的方向
		mLocationClient.setLocOption(option);
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		mLocationClient.stop();
		super.onStop();
	}

	private void filterall() {

		ax = filter1(accelerometerValues[0],100);
		ay = filter1(accelerometerValues[1],100);
		// az = filter1(accelerometerValues[2]);
		// gx = filter1(gravityValues[0]);
		// gy = filter1(gravityValues[1]);
		// gz = filter1(gravityValues[2]);
		// dx = filter1(gyroscopeValues[0]);
		// dy = filter1(gyroscopeValues[1]);
		dz = filter1(gyroscopeValues[2],100);
		cx =filter1(calculateOrientation(),1);
	}

	final SensorEventListener myListener = new SensorEventListener() {
		public void onSensorChanged(SensorEvent sensorEvent) {

			long currentUpdateTime = System.currentTimeMillis();
			if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
				magneticFieldValues = sensorEvent.values.clone();

			if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
				accelerometerValues = sensorEvent.values.clone();
				// float maxacc= sensorEvent.sensor.getMinDelay();
				// Log.e("log","acc:"+sensorEvent.sensor.getResolution());//0.00390625
				// Log.e("log","Acc: "+sensorEvent.sensor.getMinDelay());
			}
			if (sensorEvent.sensor.getType() == Sensor.TYPE_GRAVITY) {
				gravityValues = sensorEvent.values.clone();

				// sensorEvent.sensor.getMinDelay();
				// Log.e("log","GRAVITY:"+maxgra);
			}
			if (sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
				gyroscopeValues = sensorEvent.values.clone();
				// float maxgy = sensorEvent.sensor.getMinDelay();
				// Log.e("log","Gyr:"+sensorEvent.sensor.getResolution());//0.0107
				// Log.e("log","Gyr: "+sensorEvent.sensor.getMinDelay());
			}

			// calculateOrientation();

			/* 每0.5秒钟更新一次，通过检测 */
			if (currentUpdateTime - lastUpdateTime2 >= UPTATE_ORIENTATION_TIME) {// slot=0.1s
				long time = currentUpdateTime - begintime;
				// 采样频率过高时数据在小区间内抖动太厉害，使得回归在短步长难以解决。降低方向采样频率，使点稀疏
				orientlog.update(getformattime()+" "+timecount + " " + time + " " + cx + " "
						+ Orientation(cx));


				lastUpdateTime2 = currentUpdateTime;
			}

			

			if (currentUpdateTime - lastUpdateTime1 >= UPTATE_INTERVAL_TIME) {// slot=0.1s
				long time = lastUpdateTime1 - begintime;

				// confirmUpDown(gx, gy, gz);//确定手机朝向
				// 取消过滤
				filterall();// 过滤当前时间片的传感器波动
				float[] parameter = new float[4];
				parameter[0] = ax;
				parameter[1] = ay;
				parameter[2] = dz;
				parameter[3] = cx;
				
				md1.update(time, ax, ay);
				
				mystate.updata_info(parameter);// 前后加速度ay，水平加速度ax，z轴角度变化，方向变化cx
				mybump.checkstate(time, dz);// 改进的转向，带具体信息识别
				mybump.updateor(time,cx);//跟新方向列表
			//	String formattime=ft.format(new Date());
				
				//String statechoice=gpsav?;mystate.getaccstate();
				cstate.setText(getformattime() + "\n 当前方向："
						+ Orientation(cx) + ":" + cx + "\n 加减速：" + mystate.getaccstate()
						+ " \n   转向：" + mystate.getturnstate() + "\n");
				
				senlog.update(getformattime()+" "+timecount + " " + time + " " + ax + " " + ay
						+ " " + dz + " " + cx + " " + Orientation(cx));
				if(mystate.getaccstate()!=null||mystate.getturnstate()!=null)threshold.update(getformattime()+" "+timecount + " " + time + " " + mystate.getaccstate()
						+ " " + mystate.getturnstate());
				
				if(mybump.getresult()!=null){//位移判断也添加在此
				Log.e("allin", mybump.getresult());
				
				Log.e("allin", mybump.getbumptime().toString());
				double[] a=md1.getsimpledistance(mybump.getbumptime().getKey(),mybump.getbumptime().getValue());
				
				//Log.e("allin",a[0]+" "+a[1]);				
				autobumplog.update(getformattime()+" "+timecount + " " + time + " "+mybump.getresult()+" "+a[0]+" "+a[1]);
				mybump.init();}
				lastUpdateTime1 = currentUpdateTime;
				timecount++;
			}
		}

		public void onAccuracyChanged(Sensor sensor, int accuracy) {

		}
	};
	

	
	
	
	
	//格式化时间，方便不同手机之间统一时钟对比
	public String getformattime(){
		return ft.format(new Date());
	} 

	private float calculateOrientation() {
		float[] values = new float[3];
		float[] R = new float[9];
		SensorManager.getRotationMatrix(R, null, accelerometerValues,
				magneticFieldValues);
		SensorManager.getOrientation(R, values);

		// 要经过一次数据格式的转换，转换为度
		float arc = 0;
		values[0] = (float) Math.toDegrees(values[0]);

		if (values[0] < 0) {// 不加在180附近会有跃变，180<-> -180 ;改了是在360<->0
			arc = values[0] + 359;
		} else
			arc = (int) values[0];// 取整
		// values[1] = (float) Math.toDegrees(values[1]);
		// values[2] = (float) Math.toDegrees(values[2]);
		return (arc*10)/10;

	}

	// 通过手动将行使情况输入到对应log中
	private void logbyhand() {

		mButton = (Button) findViewById(R.id.acc);// 加速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest1);
				handstatelog.update(getformattime()+" "+timecount + " " + mTest1);
			}
		});
		mButton = (Button) findViewById(R.id.dec);// 减速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest2);
				handstatelog.update(getformattime()+" "+timecount + " " + mTest2);
			}
		});
		mButton = (Button) findViewById(R.id.leftturn);// 左转
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest3);
				handstatelog.update(getformattime()+" "+timecount + " " + mTest3);
			}
		});
		mButton = (Button) findViewById(R.id.rightturn);// 右转
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest4);
				handstatelog.update(getformattime()+" "+timecount + " " + mTest4);
			}
		});
		mButton = (Button) findViewById(R.id.Uturn);// 掉头
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

			//	Log.i("log", mTest5);
				handstatelog.update(getformattime()+" "+timecount + " " + mTest5);
			}
		});
		mButton = (Button) findViewById(R.id.leftlane);// 加速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest1);
				handstatelog.update(getformattime()+" "+timecount + " " + mTest6);
			}
		});
		
		mButton = (Button) findViewById(R.id.rightlane);// 加速
		mButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Log.i("log",mTest1);
				handstatelog.update(getformattime()+" "+timecount + " " + mTest7);
			}
		});
	}

	private void initSensors() {

		mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		// getDefaultSensor方法的参数值，
		// 例如，注册加速传感器可以使用Sensor.TYPE_ACCELEROMETER。在Sensor类中还定义了很多传感器常量，
		// 但要根据手机中实际的硬件配置来注册传感器。如果手机中没有相应的传感器硬件，就算注册了相应的传感器也不起任何作用。
		// 注册四种传感器
		mAccelerometer = mSensorManager
				.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);// 加速度
		// mGravity = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);// 重力
		mGyroscope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);// 角速度
		mCompass = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);// 方向

		mSensorManager.registerListener(myListener, mAccelerometer,
				3);//SENSOR_DELAY_FASTEST=0(0), SENSOR_DELAY_NORMAL=3(200),SENSOR_DELAY_GAME=1(20)
		mSensorManager.registerListener(myListener, mCompass,
				3);//SENSOR_DELAY_NORMAL
		// mSensorManager.registerListener(myListener, mGravity,
		// SensorManager.SENSOR_DELAY_NORMAL);
		mSensorManager.registerListener(myListener, mGyroscope,
				3);

		cstate = (TextView) findViewById(R.id.cstate);
		cstate.setText("4in1");
	}

	@Override
	protected void onResume() {

		super.onResume();
	}

	//
	protected void onPause() {

		mSensorManager.unregisterListener(myListener);

		super.onPause();

	}

	// 确定手机方向
	public void onAccuracyChanged(Sensor sensor, int accuracy) {

	}

	// 传入参数应为gravity三轴，后期考虑非平面
	public void confirmUpDown(float x, float y, float z) {
		if (z > 7.5 && x < 3 && y < 3) {
			up = "a";
		} else if (z < -7.5 && x < 3 && y < 3) {
			up = "b";
		} else if (x > 7.5 && z < 3 && y < 3) {
			up = "c";
		} else if (x < -7.5 && z < 3 && y < 3) {
			up = "d";
		} else if (y > 7.5 && x < 3 && z < 3) {
			up = "e";
		} else if (y < -7.5 && x < 3 && z < 3) {
			up = "f";
		}

	}

	// 只过滤小数点。参数：@待精确的值@精确位数
	public float filter1(float value,int accuracy) {
		
		return (float) Math.round(value * accuracy) / accuracy;// 精确到小数点后2位,方便计算
	}

	public String Orientation(float cx) {
		String s = "";
		if (cx <= 22.5 || cx > 337.5)
			s = "north";
		if (cx <= 337.5 && cx > 292.5)
			s = "northwest";
		if (cx >= 247.5 && cx < 292.5)
			s = "west";
		if (cx >= 202.5 && cx < 247.5)
			s = "southwest";
		if (cx >= 157.5 && cx < 202.5)
			s = "south";
		if (cx >= 112.5 && cx < 157.5)
			s = "southeast";
		if (cx >= 67.5 && cx < 112.5)
			s = "east";
		if (cx >= 22.5 && cx < 67.5)
			s = "northeast";
		return s;
	}

	// String check_info="";
	// @SuppressWarnings("deprecation")
	public void onSensorChanged(SensorEvent event) {

	}

	public class MyLocationListener implements BDLocationListener {

		@Override
		public void onReceiveLocation(BDLocation location) {//显示出现的信息
			// Receive Location
			StringBuffer sb = new StringBuffer(256);
			sb.append("time : ");
			sb.append(location.getTime());//检查gps是否在执行，后期可剔除
			sb.append("\nerror code : ");
			sb.append(location.getLocType());
			sb.append("\nlatitude : ");
			sb.append(location.getLatitude());//double类型
			sb.append("\nlontitude : ");
			sb.append(location.getLongitude());//double类型
			// sb.append("\nradius : ");
			// sb.append(location.getRadius());
			if (location.getLocType() == BDLocation.TypeGpsLocation) {
				sb.append("\nspeed : ");
				sb.append(location.getSpeed());//km/h
				sb.append("\nsatellite : ");
				sb.append(location.getSatelliteNumber());
				// sb.append("\ndirection : ");
				sb.append("\naddr : ");
				sb.append(location.getAddrStr());
				// sb.append(location.getDirection());
			} else if (location.getLocType() == BDLocation.TypeNetWorkLocation) {
				sb.append("\naddr : ");
				sb.append(location.getAddrStr());

				sb.append("\noperationers : ");
				sb.append(location.getOperators());
			}
			logMsg(sb.toString());
			
			
			//gpsspeed(location.getSpeed());
			if (location.getLocType() == 61){//仅当返回值为61时，返回的是gps定位结果
				long currenttime = System.currentTimeMillis();
				long timeslot = currenttime-begintime;// mgs内部有保存上一个时间片的字段，所以只需要系统启动后的相对时间
				//mgs.update(timeslot, location.getSpeed());
				String state=mgs.update(timeslot, location.getSpeed());
				if(state!=null){gps_speed.setText(state);gpsslog.update(location.getTime()+" "+timeslot + " " +location.getSpeed()+" "+mgs.getacc());}
				gpsllog.update(location.getTime()+" "+timeslot + " " + location.getLatitude()
						+ " " + location.getLongitude());// 输入到日志的信息
			
			//更新gps距离，gpstimer误差在秒级，这样来计算距离可能有问题，精确度不够，不过gps定位的更新最小间隔是1s，无法提高
		//	md2.updategps(gpstimer,location.getLatitude(),location.getLongitude());
			}
		}

	}
/*
	public void gpsspeed(float s) {
		float currentspeed = (float) (s/(3.6));
		String info = "当前速度：" + s + " m/s \n";
		long currenttime = System.currentTimeMillis();
		long timeslot = currenttime - gpstimer;
		if (timeslot > 5000) {
			gps_speed.setText(info + "too long for cal!");
			
		} else {
			float seconds = timeslot / 1000;
			float sc = currentspeed - gpsspeed;
			if (sc!=0)
				{
			info = info + "加速度 " + Math.abs(sc / seconds) + "m/s^2";
				gps_speed.setText(info);}
		}

		gpstimer = currenttime;
		gpsspeed = currentspeed;
		
	}
*/
	public void logMsg(String str) {
		try {
			if (LocationResult != null)
				LocationResult.setText(str);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void onDestroy() {
		super.onDestroy();
	//	Log.e("existtest", "" + System.currentTimeMillis());
		senlog.outputlast();//最后的列表可能不到1000，所以结束时强制输出，以免丢失
		orientlog.outputlast();
		threshold.outputlast();
		handstatelog.outputlast();
		gpsllog.outputlast();
		gpsslog.outputlast();
		autobumplog.outputlast();
	}
}
