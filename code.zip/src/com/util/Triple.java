
package com.util;

/**
 * A generic key-value tuple.
 */
public class Triple<K, V, W> {
	private K key;
	private V value;
	private W weight;

	/**
	 * Creates a new tuple.
	 * 
	 * @param key
	 *            The key of the tuple
	 * @param value
	 *            The value of the tuple
	 */
	public Triple(K key, V value, W weight) {
		this.key = key;
		this.value = value;
		this.weight = weight;
	}

	/**
	 * Returns the key
	 * 
	 * @return the key
	 */
	public void setKey(K key)
	{
		this.key=key;
	}
	
	
	public void setValue(V value)
	{
		this.value=value;
	}
	
	public void setWeight(W weight)
	{
		this.weight = weight;
	}
	
	public K getKey() {
		return key;
	}

	/**
	 * Returns the value
	 * 
	 * @return the value
	 */
	public V getValue() {
		return value;
	}

	public W getWeight() {
		return weight;
	}

	/**
	 * Returns a string representation of the tuple
	 * 
	 * @return a string representation of the tuple
	 */
	public String toString() {
		return key.toString() + ":" + value.toString() + ","
				+ weight.toString();
	}
}