import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
#init data
fig = plt.figure()
data = np.loadtxt("DSPLog-1.txt")#1.14
#



#get data
t=data[:,0] # time
la=data[:,1] # latitude
lo=data[:,2] #longitude
hi=data[:,3] # height
vx=data[:,4] #velocity
vy=data[:,5]
vz=data[:,6]
roll=data[:,7]#
pitch=data[:,8]
yaw=data[:,9]
ax=data[:,10] #accelerator
ay=data[:,11]
az=data[:,12]
gx=data[:,13]#gyroscope
gy=data[:,14]
gz=data[:,15]
orientation=data[:10]


#print min(min(yaw), min(roll))
#print max(max(pitch),max(yaw), max(roll))

#set panel
gps = fig.add_subplot(2, 3, 1,xlim=(min(la),max(la)), ylim=(min(lo),max(lo)))
pose = fig.add_subplot(2, 3, 2, xlim=(min(t),max(t)), ylim=(min(min(pitch),min(roll)), max(max(pitch),max(roll))))
orientation = fig.add_subplot(2, 3, 3, xlim=(min(t),max(t)), ylim=(0,360))
speed = fig.add_subplot(2, 3, 4, xlim=(min(t),max(t)), ylim=(min(min(vx),min(vy),min(vz)), max(max(vx),max(vy),max(vz))))
acc = fig.add_subplot(2, 3, 5, xlim=(min(t),max(t)), ylim=(min(min(ax),min(ay),min(az)), max(max(ax),max(ay),max(az))))
gyr = fig.add_subplot(2, 3, 6, xlim=(min(t),max(t)), ylim=(min(min(gx),min(gy),min(gz)), max(max(gx),max(gy),max(gz))))

#set lines and other elements
#1-gps [latitude,longitude]
line1, = gps.plot([], [], lw=2)
#2-pose [Roll Pitch Yaw]
line2,= pose.plot([], [], lw=2)
line3,= pose.plot([], [], lw=2)
#line4,= pose.plot([], [], lw=2)
#3-orientation # turn into circle compass
line5,= orientation.plot([], [], lw=2)
#4-speed [x,y,z]
line6,= speed.plot([], [], lw=2)
line7,= speed.plot([], [], lw=2)
line8,= speed.plot([], [], lw=2)
#5-acc [x,y,z]
line9,= acc.plot([], [], lw=2)
line10,= acc.plot([], [], lw=2)
line11,= acc.plot([], [], lw=2)
#6-gyr [x,y,z]
line12,= gyr.plot([], [], lw=2)
line13,= gyr.plot([], [], lw=2)
line14,= gyr.plot([], [], lw=2)

window=10
f=len(data)/window

def init():
    line1.set_data([], [])
    line2.set_data([], [])
    line3.set_data([], [])
    #line4.set_data([], [])
    line5.set_data([], [])
    line6.set_data([], [])
    line7.set_data([], [])
    line8.set_data([], [])
    line9.set_data([], [])
    line10.set_data([], [])
    line11.set_data([], [])
    line12.set_data([], [])
    line13.set_data([], [])
    line14.set_data([], [])
    return line1,line2,line3,line5,line6,line7,line8,line9,line10,line11,line12,line13,line14

def animate(i):
    #gps
    laa = la[i:i*20+window]
    loo = lo[i:i*20+window]
    line1.set_data(laa, loo)

    # pose
    tt = t[i:i * 20 + window]
    rroll = roll[i:i * 20 + window]
    ppitch = pitch[i:i*20 + window]
    #yyaw = yaw[i:i*20 + window]
    line2.set_data(tt, rroll)
    line3.set_data(tt, ppitch)
    #line4.set_data(tt, yyaw)

    #speed
    #tt = t[i:i*20+window]
    vxx = vx[i:i*20+window]
    vyy = vy[i:i*20 + window]
    vzz = vz[i:i*20 + window]
    line6.set_data(tt, vxx)
    line7.set_data(tt, vyy)
    line8.set_data(tt, vzz)

    #orientation
    #tt = t[i:i * 20 + window]
    orr=yaw[i:i*20+window]
    line5.set_data(tt,orr)

    #acc
    #tt = t[i:i*20+window]
    axx = ax[i:i*20+window]
    ayy = ay[i:i*20 + window]
    azz = az[i:i*20 + window]
    line9.set_data(tt, axx)
    line10.set_data(tt, ayy)
    line11.set_data(tt, azz)

    #gyr
    #tt = t[i:i*20+window]
    gxx = gx[i:i*20+window]
    gyy = gy[i:i*20 + window]
    gzz = gz[i:i*20 + window]
    line12.set_data(tt, gxx)
    line13.set_data(tt, gyy)
    line14.set_data(tt, gzz)

    return line1,line2,line3,line5,line6,line7,line8,line9,line10,line11,line12,line13,line14

anim1 = animation.FuncAnimation(fig, animate, init_func=init, frames=f, interval=10)
plt.show()
