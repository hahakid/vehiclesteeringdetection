# !/usr/bin/env python
# coding:utf-8
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib
import numpy as np
from Tkinter import *
import time



def drawPic():

    try:sampleCount = int(inputEntry.get())#从inputEntry获取相关数值
    except:
        sampleCount = 10
        #print 'input'
        inputEntry.delete(0, END)
        inputEntry.insert(0, '50')#默认值为100

# 清空图像，以使得前后两次绘制的图像不会重叠
    drawPic.f.clf()
    drawPic.a = drawPic.f.add_subplot(1, 2, 1)
    drawPic.b = drawPic.f.add_subplot(1, 2, 2)
# 在[0,100]范围内随机生成sampleCount个数据点
    x = np.random.randint(0, 100, size=sampleCount)
    y = np.random.randint(0, 100, size=sampleCount)
    color = ['b','r','y','g']

# 绘制这些随机点的散点图，颜色随机选取
    drawPic.a.scatter(x, y, s=3, color=color[np.random.randint(len(color))])
    drawPic.a.set_title('figure a')
    drawPic.b.scatter(x, y, s=3, color=color[np.random.randint(len(color))])
    drawPic.b.set_title('figure b')

    drawPic.canvas.show()

def drawgps():
    try:
        aimtime = inputEntry5.get()#从inputEntry2获取相关数值
        begintime=inputEntry4.get()
        begindate = inputEntry2.get()
        range=inputEntry3.get()
    except:
        #sampleCount = "17:28:24"
        #print 'input'
        inputEntry2.delete(0, END)
        inputEntry2.insert(0, "2017-1-08")
        inputEntry3.delete(0, END)
        inputEntry3.insert(0, '7')
        inputEntry4.delete(0, END)
        inputEntry4.insert(0, "15:20:59")
        inputEntry5.delete(0, END)
        inputEntry5.insert(0, "17:28:24")
        #exit()
    #准备数据
    #la, lo = readfile("DSPLog-1.txt")  # 读取数据文件信息
    #target = getdata("17:28:24") * 20  #目标时间
    #print sampleCount
    #print aimtime,begintime,begindate
    target=getdata(aimtime,begintime,begindate)*20


    #print target 区间
    range=int(range)*20/2 #20Hz 采样频率
    begin=target-range
    end=target+range

    cla=la[begin:end]
    clo=lo[begin:end]
    #初始化画布
# 清空图像，以使得前后两次绘制的图像不会重叠
    drawPic.f.clf()
    # 按当前gps的坐标数据来初始化坐标系，否则可能看不清
    #factor=0.9999999 #加偏移是让坐标周边空出来
    factor = 1  # 加偏移是让坐标周边空出来
    xmin=min(clo)*factor
    xmax=max(clo)*factor
    ymin=min(cla)*factor
    ymax=max(cla)*factor
    #angle

    drawPic.a = drawPic.f.add_subplot(1, 1, 1,xlim=(xmin,xmax), ylim=(ymin,ymax))
    #drawPic.a = drawPic.f.add_subplot(1, 2, 2, xlim=(xmin, xmax), ylim=(ymin, ymax))


# 在[0,100]范围内随机生成sampleCount个数据点
    #x = np.random.randint(0, 100, size=sampleCount)
    #y = np.random.randint(0, 100, size=sampleCount)
    #color = ['b','r','y','g']

# 绘制这些随机点的散点图，颜色随机选取
   #drawPic.a.plot(la[begin:end], lo[begin:end], lw=4,color='blue')
    drawPic.a.plot(clo, cla, lw=2,color='red')
    #drawPic.a.scatter(x, y, s=3, color=color[np.random.randint(len(color))])
    drawPic.a.set_title('gps')
    drawPic.canvas.show()

#海拔变化
def drawheight():
    try:
        aimtime = inputEntry5.get()#从inputEntry2获取相关数值
        begintime=inputEntry4.get()
        begindate = inputEntry2.get()
        range=inputEntry3.get()
    except:
        #sampleCount = "17:28:24"
        #print 'input'
        inputEntry2.delete(0, END)
        inputEntry2.insert(0, "2017-1-08")
        inputEntry3.delete(0, END)
        inputEntry3.insert(0, '7') #seconds
        inputEntry4.delete(0, END)
        inputEntry4.insert(0, "15:20:59")
        inputEntry5.delete(0, END)
        inputEntry5.insert(0, "15:28:24")
        #exit()
    #准备数据
    #la, lo = readfile("DSPLog-1.txt")  # 读取数据文件信息
    #target = getdata("17:28:24") * 20  #目标时间
    #print sampleCount
    #print aimtime,begintime,begindate
    target=getdata(aimtime,begintime,begindate)*20


    #print target 区间
    range=int(range)*20/2 #20Hz 采样频率
    begin=target-range
    end=target+range
    #x轴
    room=np.arange(begin,end)
    #room=room[begin:end]

    #print room
    cheight=hi[begin:end]
    #clo=lo[begin:end]
    #初始化画布
    # 清空图像，以使得前后两次绘制的图像不会重叠
    drawPic.f.clf()
    # 按当前gps的坐标数据来初始化坐标系，否则可能看不清
    #factor=0.9999999 #加偏移是让坐标周边空出来
    factor = 1  # 加偏移是让坐标周边空出来
    #xmin=min(cla)*factor
    #xmax=max(cla)*factor
    ymin=min(cheight)*factor
    ymax=max(cheight)*factor
    #angle

    drawPic.a = drawPic.f.add_subplot(1, 1, 1,xlim=(begin,end), ylim=(ymin,ymax))
    #drawPic.a = drawPic.f.add_subplot(1, 2, 2, xlim=(xmin, xmax), ylim=(ymin, ymax))

# 绘制这些随机点的散点图，颜色随机选取
    drawPic.a.plot(room, cheight, lw=3)
    #drawPic.a.scatter(x, y, s=3, color=color[np.random.randint(len(color))])
    drawPic.a.set_title('height')
    drawPic.canvas.show()

#陀螺仪三轴变化
def drawgyr():
    try:
        aimtime = inputEntry5.get()#从inputEntry2获取相关数值
        begintime=inputEntry4.get()
        begindate = inputEntry2.get()
        range=inputEntry3.get()
    except:
        #sampleCount = "17:28:24"
        #print 'input'
        inputEntry2.delete(0, END)
        inputEntry2.insert(0, "2017-1-08")
        inputEntry3.delete(0, END)
        inputEntry3.insert(0, '7')
        inputEntry4.delete(0, END)
        inputEntry4.insert(0, "15:54:00")
        inputEntry5.delete(0, END)
        inputEntry5.insert(0, "15:58:04")
        #exit()
    #准备数据
    #la, lo = readfile("DSPLog-1.txt")  # 读取数据文件信息
    #target = getdata("17:28:24") * 20  #目标时间
    #print sampleCount
    #print aimtime,begintime,begindate
    target=getdata(aimtime,begintime,begindate)*20


    #print target 区间
    range=int(range)*20/2 #20Hz 采样频率
    begin=target-range
    end=target+range
    #x轴
    room=np.arange(begin,end)
    #room=room[begin:end]

    #print room
    cgx=gx[begin:end]
    cgy=gy[begin:end]
    cgz=gz[begin:end]
    #cheight=hi[begin:end]
    #clo=lo[begin:end]
    #初始化画布
    # 清空图像，以使得前后两次绘制的图像不会重叠
    drawPic.f.clf()
    # 按当前gps的坐标数据来初始化坐标系，否则可能看不清
    #factor=0.9999999 #加偏移是让坐标周边空出来
    factor = 1  # 加偏移是让坐标周边空出来
    #xmin=min(cla)*factor
    #xmax=max(cla)*factor
    cmin=min(cgz)*factor
    cmax=max(cgz)*factor
    #angle

    drawPic.a = drawPic.f.add_subplot(1, 1, 1,xlim=(begin,end), ylim=(cmin,cmax))
    #drawPic.a = drawPic.f.add_subplot(1, 2, 2, xlim=(xmin, xmax), ylim=(ymin, ymax))

# 绘制这些随机点的散点图，颜色随机选取
    drawPic.a.plot(room, cgx, lw=3)
    drawPic.a.plot(room, cgy, lw=3)
    drawPic.a.plot(room, cgz, lw=3,color='red')

    #drawPic.a.scatter(x, y, s=3, color=color[np.random.randint(len(color))])
    drawPic.a.set_title('gyroscope')
    drawPic.canvas.show()


# get all gps location and other data from the DSP-file( fname)
def readfile(fname):
    data = np.loadtxt(fname)
    t = data[:, 0]  # time
    la = data[:, 1]  # latitude
    lo = data[:, 2]  # longitude
    ori = data[:10]
    hi = data[:, 3]  # height
    gx = data[:, 13]  # gyroscope
    gy = data[:, 14]
    gz = data[:, 15]
    return la,lo,ori,hi,gx,gy,gz

#calcuate the target frame array according to the time
#bt="17:20:59",begin time of this test
#def getdata(ct,bt="17:20:59",date="2017-1-14"):
def getdata(ct, bt, date):
    print ct,bt,date
    begintime = time.strptime(date+" "+bt, "%Y-%m-%d %H:%M:%S")
    #print begintime
    currenttime = time.strptime(date+" "+ct, "%Y-%m-%d %H:%M:%S")
    btStamp = int(time.mktime(begintime))
    ctStamp = int(time.mktime(currenttime))
    return ctStamp-btStamp



if __name__ == '__main__':
    matplotlib.use('TkAgg')

    la, lo, ori, hi, gx, gy, gz=readfile("pos320.txt")#读取数据文件信息


    #target=getdata("17:28:24")*20 #目标时间，可选的@总起始时间和日期。后两个需要初始化的时候进行修改，考虑量不大，手动
    #print la[target-150:target+150],lo[target-150:target+150],target


    root = Tk()# tk loop begin

    #第一行
    # 在Tk的GUI上放置一个画布，并用.grid()来调整布局
    drawPic.f = Figure(figsize=(5, 4), dpi=100)
    #drawPic.f = Figure(figsize=(5, 4))
    #第一个元素为 canvas ，位于row=0， 占3列宽度
    drawPic.canvas = FigureCanvasTkAgg(drawPic.f, master=root)
    drawPic.canvas.show()
    drawPic.canvas.get_tk_widget().grid(row=0, columnspan=5)

    #第二行
    # 放置标签、文本框和按钮等部件，并设置文本框的默认值和按钮的事件函数
    Label(root, text='num of node：').grid(row=1, column=0)

    inputEntry = Entry(root)
    inputEntry.grid(row=1, column=1)
    inputEntry.insert(0, '100')


    '''
    button 前面的是 自身属性，
    后面 grid是row=1 该行放小部件,与前面一致，改为2之后会在下一行进行绘制（0行为图片）
    column=2 列放部件，左起第3个（0为第一个），因为0是text，1是inputEntry
    columnspan=3部件占用3列
    '''
    #Button(root, text='draw', command=drawPic).grid(row=1, column=2, columnspan=1)
    Button(root, text='height', command=drawheight).grid(row=1, column=2, columnspan=1)
    Button(root, text='gps', command=drawgps).grid(row=1, column=3, columnspan=1)
    Button(root, text='gyr', command=drawgyr).grid(row=1, column=4, columnspan=1)

    #第三行
    #输入本次的记录的初始时间，也就是惯导开始的时间，从RTGnssInsNav读取的第一帧时间
    Label(root, text='Date：').grid(row=2, column=0)
    inputEntry2 = Entry(root)
    inputEntry2.grid(row=2, column=1)
    inputEntry2.insert(0, "2017-1-08")
    #需要查看的时间区间，总时长
    Label(root, text='Interval：').grid(row=2, column=2)
    #想要绘制的时间间隔，以aimed time为中心，前后1/2 的一个区间
    inputEntry3 = Entry(root)
    inputEntry3.grid(row=2, column=3)
    inputEntry3.insert(0, '7')

    #第四行，开始时间
    Label(root, text='Begin Time：').grid(row=3, column=0)
    inputEntry4 = Entry(root)
    inputEntry4.grid(row=3, column=1)
    inputEntry4.insert(0, "15:54:00")

    #输入想要看的目标时间，这个对应每次手动标记的时间戳
    #1.8的园博园时间范围是 3:54-4:31 15：54-16：31
    Label(root, text='Aimed Time：').grid(row=3, column=2)
    inputEntry5 = Entry(root)
    inputEntry5.grid(row=3, column=3)
    inputEntry5.insert(0, "15:56:24")


    # 启动事件循环
    root.mainloop() #tk loop endbuttontest.py