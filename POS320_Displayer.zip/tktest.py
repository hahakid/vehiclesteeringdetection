#!/usr/bin/python
# -*- coding: UTF-8 -*-

from Tkinter import *
root = Tk()
li=[1,2,3,4,5,6,7]
movie=['a','b','c','d','e']
listb=Listbox(root)
lista=Listbox(root)
for item in li:
    listb.insert(0,item)

for item in movie:
    lista.insert(0,item)

lista.pack()
listb.pack()




root.mainloop()