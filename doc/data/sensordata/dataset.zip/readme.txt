[a/g][x/y/z]_feature	
	a means accelerometer
	g means gyroscope
	x/y/z is the corresponde axis of the sensor

class={lt,rt,ll,rl,ut,null}
	lt=left-turn
	rt=right-turn
	ll=left-lane
	rl=right-lane
	ut=u-turn
	null=error detected actions from the multiwave filter